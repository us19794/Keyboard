# AMOLED Keyboard
Push this project to GitHub. The workflow in .github/workflows/build.yml builds the debug APK
(Actions tab > latest run > Artifacts). Install it, open the app, tap "Enable keyboard", then "Switch keyboard".
