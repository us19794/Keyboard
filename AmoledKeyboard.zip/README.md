# AMOLED Keyboard
Push this project to GitHub. The workflow in .github/workflows/build.yml builds the debug APK
(Actions tab > latest run > Artifacts). Install it, open the app, tap "Enable", then "Switch".
All look/feel options (colors, roundness, animation speed, autocorrect...) live in the app.

Fonts: headings in the settings app use Caladea (Apache License 2.0), bundled at app/src/main/res/font/caladea_regular.ttf.
Key fonts: Inter (SIL OFL) and Carlito (SIL OFL) are bundled in res/font; the rest use Android system fonts.

Voice typing: "Phone" uses Android's built-in speech service. "Gemini" (free key from aistudio.google.com/apikey) and
"Whisper" (free key from console.groq.com, or any OpenAI-compatible endpoint) send your recording to that provider.
Word prediction learns on the phone only; clear it any time from the app.
