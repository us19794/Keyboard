package com.example.amoledkeyboard

import android.content.Context

class ClipItem(var text: String, var pinned: Boolean, var time: Long)

/** Copied text, kept privately on the phone. Pinned items are never trimmed or expired. */
class ClipStore(private val ctx: Context) {
    private val store = ctx.getSharedPreferences("kb_clip", Context.MODE_PRIVATE)
    val items = ArrayList<ClipItem>()
    private var epoch = -1

    init {
        load()
    }

    fun syncEpoch() {
        if (Prefs.sp(ctx).getInt("clip_epoch", 0) != epoch) load()
    }

    private fun load() {
        items.clear()
        epoch = Prefs.sp(ctx).getInt("clip_epoch", 0)
        val raw = store.getString("items", "") ?: ""
        if (raw.isEmpty()) return
        for (rec in raw.split('\u001E')) {
            val p = rec.split('\u001F', limit = 3)
            if (p.size == 3) items.add(ClipItem(p[2], p[0] == "1", p[1].toLongOrNull() ?: 0L))
        }
    }

    private fun save() {
        val s = items.joinToString("\u001E") { (if (it.pinned) "1" else "0") + "\u001F" + it.time + "\u001F" + it.text }
        store.edit().putString("items", s).apply()
    }

    /** Returns true if this was a new item. */
    fun add(text: String): Boolean {
        syncEpoch()
        val t = text.replace('\u001E', ' ').replace('\u001F', ' ')
        if (t.isBlank() || t.length > 5000) return false
        val now = System.currentTimeMillis()
        val ex = items.firstOrNull { it.text == t }
        if (ex != null) ex.time = now else items.add(ClipItem(t, false, now))
        val unpinned = items.filter { !it.pinned }.sortedByDescending { it.time }
        if (unpinned.size > 40) items.removeAll(unpinned.drop(40).toSet())
        save()
        return ex == null
    }

    fun togglePin(item: ClipItem) {
        item.pinned = !item.pinned
        save()
    }

    fun remove(item: ClipItem) {
        items.remove(item)
        save()
    }

    fun clearUnpinned() {
        items.removeAll { !it.pinned }
        save()
    }

    fun prune(keepMs: Long) {
        if (keepMs <= 0L) return
        val now = System.currentTimeMillis()
        if (items.removeAll { !it.pinned && now - it.time > keepMs }) save()
    }

    fun sorted(): List<ClipItem> =
        items.sortedWith(compareByDescending<ClipItem> { it.pinned }.thenByDescending { it.time })
}
