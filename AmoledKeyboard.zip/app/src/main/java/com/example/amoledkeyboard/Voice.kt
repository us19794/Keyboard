package com.example.amoledkeyboard

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Records 16 kHz mono audio and returns it as a WAV file (max 90 seconds). */
class WavRecorder {
    @Volatile private var running = false
    private var thread: Thread? = null
    private var record: AudioRecord? = null
    private val pcm = ByteArrayOutputStream()
    private val rate = 16000

    @SuppressLint("MissingPermission")
    fun start(): Boolean {
        val min = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        if (min <= 0) return false
        val rec = AudioRecord(
            MediaRecorder.AudioSource.MIC, rate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, rate)
        )
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return false
        }
        pcm.reset()
        record = rec
        running = true
        rec.startRecording()
        thread = Thread {
            val buf = ByteArray(4096)
            val limit = rate * 2 * 90
            while (running && pcm.size() < limit) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) pcm.write(buf, 0, n) else if (n < 0) break
            }
        }.also { it.start() }
        return true
    }

    private fun teardown() {
        running = false
        try { thread?.join(1000) } catch (e: InterruptedException) { }
        try { record?.stop() } catch (e: Exception) { }
        try { record?.release() } catch (e: Exception) { }
        record = null
        thread = null
    }

    /** Stops and returns a WAV, or null if there was (almost) no audio. */
    fun stop(): ByteArray? {
        teardown()
        val data = pcm.toByteArray()
        pcm.reset()
        if (data.size < rate * 2 / 3) return null
        return wav(data)
    }

    fun cancel() {
        teardown()
        pcm.reset()
    }

    private fun wav(data: ByteArray): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + data.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16)
        h.putShort(1.toShort()); h.putShort(1.toShort())
        h.putInt(rate); h.putInt(rate * 2)
        h.putShort(2.toShort()); h.putShort(16.toShort())
        h.put("data".toByteArray()); h.putInt(data.size)
        val out = ByteArrayOutputStream()
        out.write(h.array())
        out.write(data)
        return out.toByteArray()
    }
}

/** Cloud speech-to-text. Both calls block, so run them off the main thread. */
object Transcriber {

    fun gemini(key: String, model: String, wav: ByteArray): String {
        val b64 = Base64.encodeToString(wav, Base64.NO_WRAP)
        val prompt = "Transcribe this audio exactly as spoken. Use normal punctuation and " +
            "capitalization. Output only the transcript text and nothing else. " +
            "If there is no speech, output nothing."
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", "audio/wav").put("data", b64)
                )
            )
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        val url = "https://generativelanguage.googleapis.com/v1beta/models/${model.trim()}:generateContent"
        val resp = post(
            url, mapOf("x-goog-api-key" to key.trim()),
            "application/json", body.toString().toByteArray()
        )
        val cands = JSONObject(resp).optJSONArray("candidates") ?: return ""
        val content = cands.optJSONObject(0)?.optJSONObject("content") ?: return ""
        val ps = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) sb.append(ps.optJSONObject(i)?.optString("text", "") ?: "")
        return sb.toString().trim()
    }

    fun whisper(url: String, key: String, model: String, wav: ByteArray): String {
        val boundary = "----kbBoundary" + System.currentTimeMillis()
        val out = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            out.write(
                ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name +
                    "\"\r\n\r\n" + value + "\r\n").toByteArray()
            )
        }
        field("model", model.trim())
        field("response_format", "json")
        field("temperature", "0")
        out.write(
            ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; " +
                "filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n").toByteArray()
        )
        out.write(wav)
        out.write(("\r\n--" + boundary + "--\r\n").toByteArray())
        val resp = post(
            url.trim(), mapOf("Authorization" to "Bearer " + key.trim()),
            "multipart/form-data; boundary=$boundary", out.toByteArray()
        )
        return JSONObject(resp).optString("text", "").trim()
    }

    private fun post(urlStr: String, headers: Map<String, String>, contentType: String, body: ByteArray): String {
        val c = URL(urlStr).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 15000
            c.readTimeout = 60000
            c.setRequestProperty("Content-Type", contentType)
            for ((k, v) in headers) c.setRequestProperty(k, v)
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IOException("HTTP $code")
            return text
        } finally {
            c.disconnect()
        }
    }
}
