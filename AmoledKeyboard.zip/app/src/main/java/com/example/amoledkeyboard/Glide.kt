package com.example.amoledkeyboard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.ln

/**
 * Turns a finger path over the letter keys into words.
 * The path is compared with the ideal path through each candidate word's keys (resampled to the
 * same number of points); common words get a small bonus.
 */
class GlideDecoder {
    private var words: Array<String> = emptyArray()
    private val byFirst = Array(26) { ArrayList<Int>() }
    @Volatile var ready = false

    fun load(ctx: Context) {
        if (ready) return
        try {
            val list = ArrayList<String>(110000)
            ctx.resources.openRawResource(R.raw.words).bufferedReader().useLines { seq ->
                seq.forEach { if (it.length >= 2) list.add(it) }
            }
            val arr = list.toTypedArray()
            for (i in arr.indices) {
                val c = arr[i][0] - 'a'
                if (c in 0..25) byFirst[c].add(i)
            }
            words = arr
            ready = true
        } catch (e: Exception) {
            // glide stays off if the word list can't be read
        }
    }

    private fun dist(a: PointF, b: PointF): Float = hypot(a.x - b.x, a.y - b.y)

    private fun pathLen(p: List<PointF>): Float {
        var t = 0f
        for (i in 1 until p.size) t += dist(p[i - 1], p[i])
        return t
    }

    private fun resample(p: List<PointF>, n: Int): Array<PointF>? {
        val total = pathLen(p)
        if (total <= 0f || p.size < 2) return null
        val step = total / (n - 1)
        val out = ArrayList<PointF>(n)
        out.add(PointF(p[0].x, p[0].y))
        var cur = PointF(p[0].x, p[0].y)
        var needed = step
        var idx = 1
        while (idx < p.size && out.size < n) {
            val b = p[idx]
            val seg = dist(cur, b)
            if (seg >= needed && seg > 0f) {
                val t = needed / seg
                val np = PointF(cur.x + (b.x - cur.x) * t, cur.y + (b.y - cur.y) * t)
                out.add(np)
                cur = np
                needed = step
            } else {
                needed -= seg
                cur = PointF(b.x, b.y)
                idx++
            }
        }
        while (out.size < n) out.add(PointF(p.last().x, p.last().y))
        return out.toTypedArray()
    }

    /** Best guesses (most likely first, at most 3). Empty if the path is too short or nothing fits. */
    fun decode(
        pts: List<PointF>,
        centers: Map<Char, PointF>,
        keyW: Float,
        learned: Map<String, Int>
    ): List<String> {
        if (!ready || pts.size < 2 || keyW <= 0f) return emptyList()
        val n = 32
        val userLen = pathLen(pts)
        if (userLen < keyW * 1.2f) return emptyList()
        val user = resample(pts, n) ?: return emptyList()
        val start = pts.first()
        val end = pts.last()
        val near = 1.7f * keyW
        val firstOk = BooleanArray(26)
        val lastOk = BooleanArray(26)
        for ((c, p) in centers) {
            val i = c - 'a'
            if (i in 0..25) {
                if (dist(p, start) <= near) firstOk[i] = true
                if (dist(p, end) <= near) lastOk[i] = true
            }
        }
        val best = HashMap<String, Float>()

        fun consider(w: String, rank: Int, boost: Float) {
            val tpl = ArrayList<PointF>(w.length)
            var prev = '\u0000'
            for (ch in w) {
                if (ch == prev) continue
                prev = ch
                val p = centers[ch] ?: return
                tpl.add(p)
            }
            if (tpl.size < 2) return
            val tl = pathLen(tpl)
            if (tl < userLen * 0.45f || tl > userLen * 2.2f) return
            val rs = resample(tpl, n) ?: return
            var d = 0f
            for (k in 0 until n) d += dist(user[k], rs[k])
            d /= (n * keyW)
            if (d > 1.4f) return
            val cost = d + 0.06f * ln(1f + rank) - boost
            val old = best[w]
            if (old == null || cost < old) best[w] = cost
        }

        for (fi in 0 until 26) {
            if (!firstOk[fi]) continue
            for (idx in byFirst[fi]) {
                val w = words[idx]
                val li = w[w.length - 1] - 'a'
                if (li < 0 || li > 25 || !lastOk[li]) continue
                consider(w, idx, 0f)
            }
        }
        for ((w, c) in learned) {
            if (w.length < 2) continue
            val f = w[0] - 'a'
            val l = w[w.length - 1] - 'a'
            if (f < 0 || f > 25 || l < 0 || l > 25 || !firstOk[f] || !lastOk[l]) continue
            if (!w.all { it in 'a'..'z' }) continue
            consider(w, 30, 0.1f * ln(1f + c))
        }
        return best.entries.sortedBy { it.value }.take(3).map { it.key }
    }
}

/** Draws the glide trail on top of the keyboard. It never takes touches. */
class TrailView(ctx: Context) : View(ctx) {
    private val pts = ArrayList<PointF>()
    private val loc = IntArray(2)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 8f
    }
    var color: Int = Color.WHITE

    fun setStroke(px: Float) {
        paint.strokeWidth = px
    }

    fun add(x: Float, y: Float) {
        pts.add(PointF(x, y))
        if (pts.size > 160) pts.removeAt(0)
        invalidate()
    }

    fun clear() {
        pts.clear()
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        if (pts.size < 2) return
        getLocationOnScreen(loc)
        paint.color = color
        val n = pts.size
        for (i in 1 until n) {
            paint.alpha = 50 + 205 * i / n
            canvas.drawLine(
                pts[i - 1].x - loc[0], pts[i - 1].y - loc[1],
                pts[i].x - loc[0], pts[i].y - loc[1], paint
            )
        }
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean = false
}
