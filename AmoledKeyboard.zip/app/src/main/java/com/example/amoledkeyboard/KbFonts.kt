package com.example.amoledkeyboard

import android.content.Context
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat

/** Fonts the user can pick for the keys. Index is stored in prefs under "font". */
object KbFonts {
    val names = listOf(
        "Default",    // 0 system sans, medium
        "Serif",      // 1 Caladea (same serif as the settings headings)
        "Inter",      // 2 bundled
        "Carlito",    // 3 bundled, soft humanist sans
        "Mono",       // 4 system monospace
        "Condensed",  // 5 system condensed sans
        "Light",      // 6 system light sans
        "Classic",    // 7 system serif
        "Casual"      // 8 system casual / handwriting
    )

    fun typeface(ctx: Context, index: Int): Typeface {
        return try {
            val t: Typeface? = when (index) {
                1 -> ResourcesCompat.getFont(ctx, R.font.caladea_regular)
                2 -> ResourcesCompat.getFont(ctx, R.font.inter_medium)
                3 -> ResourcesCompat.getFont(ctx, R.font.carlito_regular)
                4 -> Typeface.create("monospace", Typeface.NORMAL)
                5 -> Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                6 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                7 -> Typeface.create("serif", Typeface.NORMAL)
                8 -> Typeface.create("casual", Typeface.NORMAL)
                else -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            t ?: Typeface.DEFAULT
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }
}
