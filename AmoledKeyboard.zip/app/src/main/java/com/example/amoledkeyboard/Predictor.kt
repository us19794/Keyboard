package com.example.amoledkeyboard

import android.content.Context

/**
 * Local word prediction. Combines a small built-in vocabulary with what the user actually types
 * (learned words and word pairs, stored privately on the phone).
 */
class Predictor(private val ctx: Context) {

    private val store = ctx.getSharedPreferences("kb_learn", Context.MODE_PRIVATE)
    private val uni = HashMap<String, Int>()
    private val bi = HashMap<String, HashMap<String, Int>>()
    private var dirty = 0
    private var epoch = -1

    init {
        load()
    }

    /** Reload if the user cleared the learned words from the app. */
    fun syncEpoch() {
        if (Prefs.sp(ctx).getInt("learn_epoch", 0) != epoch) load()
    }

    private fun load() {
        uni.clear()
        bi.clear()
        dirty = 0
        epoch = Prefs.sp(ctx).getInt("learn_epoch", 0)
        store.getString("uni", "")?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 2) p[1].toIntOrNull()?.let { uni[p[0]] = it }
        }
        store.getString("bi", "")?.lineSequence()?.forEach { line ->
            val p = line.split('\t')
            if (p.size == 3) p[2].toIntOrNull()?.let { bi.getOrPut(p[0]) { HashMap() }[p[1]] = it }
        }
    }

    fun learn(prev: String?, word: String) {
        syncEpoch()
        uni[word] = (uni[word] ?: 0) + 1
        val m = bi.getOrPut(prev ?: START) { HashMap() }
        m[word] = (m[word] ?: 0) + 1
        dirty++
        if (dirty >= 20) save()
    }

    fun save() {
        if (dirty == 0) return
        prune()
        val u = StringBuilder()
        for ((w, c) in uni) u.append(w).append('\t').append(c).append('\n')
        val b = StringBuilder()
        for ((p, m) in bi) for ((n, c) in m) b.append(p).append('\t').append(n).append('\t').append(c).append('\n')
        store.edit().putString("uni", u.toString()).putString("bi", b.toString()).apply()
        dirty = 0
    }

    private fun prune() {
        if (uni.size > 4000) {
            val keep = uni.entries.sortedByDescending { it.value }.take(3000).map { it.key to it.value }
            uni.clear()
            for ((k, v) in keep) uni[k] = v
        }
        val total = bi.values.sumOf { it.size }
        if (total > 8000) {
            for (m in bi.values) m.entries.removeAll { it.value <= 1 }
            bi.entries.removeAll { it.value.isEmpty() }
        }
    }

    /** Completions for a half-typed word. [prev] is the word before it (or null at a sentence start). */
    fun complete(prefix: String, prev: String?): List<String> {
        val p = prefix.lowercase()
        val key = prev ?: START
        val scores = HashMap<String, Double>()
        for (w in SEED_WORDS) if (w.startsWith(p) && w != p) scores[w] = 1.0 - w.length * 0.01
        for ((w, c) in uni) if (w.startsWith(p) && w != p) scores[w] = (scores[w] ?: 0.0) + c * 10.0
        bi[key]?.forEach { (w, c) ->
            if (w.startsWith(p) && w != p) scores[w] = (scores[w] ?: 0.0) + c * 40.0
        }
        SEED_BI[key]?.forEachIndexed { i, w ->
            if (w.startsWith(p) && w != p) scores[w] = (scores[w] ?: 0.0) + (5 - i) * 8.0
        }
        return scores.entries.sortedByDescending { it.value }.take(3).map { it.key }
    }

    /** Likely next words after [prev]. */
    fun next(prev: String?): List<String> {
        val key = prev ?: START
        val scores = HashMap<String, Double>()
        bi[key]?.forEach { (w, c) -> scores[w] = c * 40.0 }
        SEED_BI[key]?.forEachIndexed { i, w -> scores[w] = (scores[w] ?: 0.0) + (5 - i) * 8.0 }
        val out = scores.entries.sortedByDescending { it.value }.map { it.key }.toMutableList()
        val fallback = if (prev == null) listOf("i", "the", "you") else listOf("the", "a", "to")
        for (d in fallback) if (out.size < 3 && d !in out) out.add(d)
        return out.take(3)
    }

    companion object {
        private const val START = "<s>"

        private val SEED_BI: Map<String, List<String>> = mapOf(
            START to listOf("i", "the", "you", "we", "it", "thanks", "hey", "hello"),
            "i" to listOf("am", "have", "think", "will", "don't", "love", "need", "want", "can", "just"),
            "i'm" to listOf("not", "going", "sorry", "so", "just", "here", "fine"),
            "you" to listOf("are", "can", "have", "will", "want", "know", "need", "too"),
            "we" to listOf("are", "can", "have", "will", "need", "should"),
            "they" to listOf("are", "have", "will", "were", "said"),
            "he" to listOf("is", "was", "has", "said", "will"),
            "she" to listOf("is", "was", "has", "said", "will"),
            "it" to listOf("is", "was", "will", "would", "looks"),
            "it's" to listOf("a", "not", "the", "so", "been", "time"),
            "the" to listOf("best", "first", "same", "other", "most", "new", "only", "way"),
            "a" to listOf("lot", "little", "good", "few", "great", "new", "bit"),
            "to" to listOf("be", "do", "the", "get", "go", "see", "make", "have"),
            "of" to listOf("the", "a", "course", "my", "this", "it"),
            "in" to listOf("the", "a", "my", "this", "order", "time"),
            "on" to listOf("the", "my", "a", "it", "your", "time"),
            "at" to listOf("the", "home", "least", "all", "work", "once"),
            "for" to listOf("the", "a", "you", "me", "your", "now"),
            "with" to listOf("the", "you", "a", "me", "my", "your"),
            "and" to listOf("i", "the", "then", "you", "we", "a"),
            "but" to listOf("i", "it", "the", "you", "then"),
            "so" to listOf("much", "i", "good", "sorry", "far", "I'm"),
            "is" to listOf("a", "the", "it", "there", "not", "that"),
            "are" to listOf("you", "there", "we", "they", "the", "not"),
            "was" to listOf("a", "the", "it", "not", "going", "just"),
            "do" to listOf("you", "not", "it", "we", "that"),
            "don't" to listOf("know", "want", "think", "have", "worry", "forget"),
            "can" to listOf("you", "i", "we", "be", "do", "help"),
            "can't" to listOf("wait", "believe", "find", "do", "say"),
            "will" to listOf("be", "you", "do", "have", "see"),
            "would" to listOf("you", "be", "like", "have", "love"),
            "could" to listOf("you", "be", "have", "not", "do"),
            "should" to listOf("be", "i", "we", "have", "do"),
            "have" to listOf("a", "to", "you", "been", "the", "any"),
            "has" to listOf("been", "a", "the", "to", "not"),
            "been" to listOf("a", "working", "there", "so", "to", "very"),
            "going" to listOf("to", "on", "home", "out", "back"),
            "want" to listOf("to", "you", "a", "the", "it"),
            "need" to listOf("to", "a", "you", "help", "some"),
            "like" to listOf("a", "to", "the", "that", "it", "this"),
            "love" to listOf("you", "it", "this", "to", "the"),
            "think" to listOf("so", "it", "that", "about", "we", "I"),
            "know" to listOf("what", "that", "how", "if", "you", "it"),
            "let" to listOf("me", "us", "you", "know", "it"),
            "see" to listOf("you", "the", "what", "if", "it"),
            "get" to listOf("it", "a", "the", "back", "some", "to"),
            "just" to listOf("a", "wanted", "want", "like", "got", "the"),
            "not" to listOf("sure", "a", "the", "really", "going", "to"),
            "very" to listOf("much", "good", "well", "sorry", "nice"),
            "really" to listOf("good", "want", "need", "like", "sorry"),
            "good" to listOf("morning", "night", "luck", "to", "job", "evening"),
            "great" to listOf("job", "to", "idea", "thanks", "day"),
            "thank" to listOf("you"),
            "thanks" to listOf("for", "a", "so", "again", "man"),
            "how" to listOf("are", "do", "to", "about", "much", "is"),
            "what" to listOf("is", "are", "do", "about", "time", "happened"),
            "when" to listOf("are", "is", "do", "you", "i", "will"),
            "where" to listOf("are", "is", "do", "you", "did"),
            "why" to listOf("are", "is", "do", "not", "did"),
            "please" to listOf("let", "send", "call", "help", "don't", "do"),
            "sorry" to listOf("for", "about", "i", "to", "but"),
            "hello" to listOf("there", "how", "I", "everyone"),
            "hey" to listOf("there", "how", "what", "are", "man"),
            "okay" to listOf("thanks", "i", "then", "so", "cool", "great"),
            "yes" to listOf("i", "please", "of", "it", "that", "sure"),
            "no" to listOf("problem", "worries", "way", "one", "thanks", "idea"),
            "let's" to listOf("go", "see", "do", "talk", "meet", "get"),
            "see you" to listOf("later", "soon", "tomorrow"),
            "this" to listOf("is", "morning", "time", "week", "one", "was"),
            "that" to listOf("is", "was", "would", "sounds", "works", "I"),
            "there" to listOf("is", "are", "was", "will", "you"),
            "my" to listOf("name", "friend", "phone", "own", "best", "mind"),
            "your" to listOf("name", "own", "best", "message", "help"),
            "me" to listOf("know", "a", "the", "too", "when", "if"),
            "if" to listOf("you", "i", "it", "we", "not", "the"),
            "because" to listOf("i", "of", "it", "the", "you", "they"),
            "about" to listOf("the", "it", "that", "a", "this", "you")
        )

        private val SEED_WORDS: List<String> = listOf(
            "about", "above", "after", "again", "all", "also", "always", "am", "and", "any",
            "are", "around", "as", "ask", "at", "away", "back", "be", "because", "been",
            "before", "being", "best", "better", "between", "big", "but", "by", "call", "came",
            "can", "come", "could", "day", "did", "do", "does", "done", "don't", "down",
            "each", "even", "every", "feel", "find", "first", "for", "from", "get", "give",
            "go", "going", "good", "got", "great", "had", "has", "have", "he", "hello",
            "help", "her", "here", "hey", "him", "his", "home", "how", "i'm", "i'll",
            "i've", "if", "in", "into", "is", "it", "it's", "just", "keep", "know",
            "last", "later", "let", "like", "little", "long", "look", "love", "make", "many",
            "maybe", "me", "more", "most", "much", "my", "need", "never", "new", "next",
            "no", "not", "now", "of", "off", "okay", "on", "one", "only", "or",
            "other", "our", "out", "over", "people", "please", "really", "right", "said", "same",
            "say", "see", "she", "should", "so", "some", "something", "sorry", "still", "sure",
            "take", "tell", "thank", "thanks", "that", "the", "their", "them", "then", "there",
            "they", "thing", "think", "this", "time", "to", "today", "tomorrow", "tonight", "too",
            "try", "up", "us", "use", "very", "want", "was", "way", "we", "well",
            "went", "were", "what", "when", "where", "which", "who", "why", "will", "with",
            "work", "would", "yes", "you", "your", "you're", "can't", "won't", "didn't", "doesn't",
            "isn't", "wasn't", "couldn't", "wouldn't", "shouldn't", "that's", "what's", "there's",
            "let's", "morning", "night", "evening", "weekend", "meeting", "message", "phone",
            "friend", "family", "tonight", "later", "soon", "again", "please", "welcome",
            "congratulations", "birthday", "happy", "awesome", "beautiful", "important",
            "probably", "actually", "definitely", "absolutely", "anyway", "already", "another",
            "because", "before", "different", "everything", "everyone", "something", "someone",
            "sometimes", "together", "understand", "wonderful", "yesterday"
        ).distinct()
    }
}
