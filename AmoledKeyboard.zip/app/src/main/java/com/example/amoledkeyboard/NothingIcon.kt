package com.example.amoledkeyboard

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Thin monochrome line icons with dot-matrix accents, in the spirit of Nothing OS.
 * state: for SHIFT, 0 = off, 1 = shift (filled), 2 = caps lock (filled + bar).
 */
class NothingIcon(
    private val type: Type,
    tint: Int,
    private val state: Int = 0,
    private val sizePx: Int
) : Drawable() {

    enum class Type { SHIFT, BACKSPACE, ENTER, EMOJI, MIC }

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        strokeWidth = 1.8f
        color = tint
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = tint
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = b.width() / 24f
        canvas.save()
        canvas.translate(b.left.toFloat(), b.top.toFloat())
        canvas.scale(s, s)
        when (type) {
            Type.SHIFT -> {
                val p = Path().apply {
                    moveTo(12f, 3.5f); lineTo(20.5f, 12.5f); lineTo(15.5f, 12.5f)
                    lineTo(15.5f, 18f); lineTo(8.5f, 18f); lineTo(8.5f, 12.5f)
                    lineTo(3.5f, 12.5f); close()
                }
                if (state >= 1) canvas.drawPath(p, fill)
                canvas.drawPath(p, stroke)
                if (state == 2) canvas.drawLine(8.5f, 21.2f, 15.5f, 21.2f, stroke)
            }
            Type.BACKSPACE -> {
                val p = Path().apply {
                    moveTo(9f, 5.5f); lineTo(20.5f, 5.5f); lineTo(20.5f, 18.5f)
                    lineTo(9f, 18.5f); lineTo(3f, 12f); close()
                }
                canvas.drawPath(p, stroke)
                canvas.drawLine(12.8f, 9.5f, 17f, 14.5f, stroke)
                canvas.drawLine(17f, 9.5f, 12.8f, 14.5f, stroke)
            }
            Type.ENTER -> {
                val p = Path().apply {
                    moveTo(19.5f, 5f); lineTo(19.5f, 13f); lineTo(5f, 13f)
                    moveTo(9f, 8.8f); lineTo(4.8f, 13f); lineTo(9f, 17.2f)
                }
                canvas.drawPath(p, stroke)
            }
            Type.MIC -> {
                val cap = RectF(9f, 3f, 15f, 14f)
                if (state >= 1) canvas.drawRoundRect(cap, 3f, 3f, fill)
                canvas.drawRoundRect(cap, 3f, 3f, stroke)
                canvas.drawArc(RectF(6f, 7f, 18f, 19f), 0f, 180f, false, stroke)
                canvas.drawLine(12f, 19f, 12f, 21.5f, stroke)
                canvas.drawLine(9f, 21.5f, 15f, 21.5f, stroke)
            }
            Type.EMOJI -> {
                for (i in 0 until 18) {
                    val a = 2.0 * PI * i / 18.0
                    canvas.drawCircle(12f + 9f * cos(a).toFloat(), 12f + 9f * sin(a).toFloat(), 0.95f, fill)
                }
                canvas.drawCircle(8.8f, 9.8f, 1.35f, fill)
                canvas.drawCircle(15.2f, 9.8f, 1.35f, fill)
                val mouth = listOf(
                    7.8f to 13.8f, 9.4f to 15.6f, 12f to 16.4f, 14.6f to 15.6f, 16.2f to 13.8f
                )
                for (m in mouth) canvas.drawCircle(m.first, m.second, 0.95f, fill)
            }
        }
        canvas.restore()
    }

    override fun setAlpha(alpha: Int) {
        stroke.alpha = alpha
        fill.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        stroke.colorFilter = colorFilter
        fill.colorFilter = colorFilter
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    override fun getIntrinsicWidth(): Int = sizePx
    override fun getIntrinsicHeight(): Int = sizePx
}
