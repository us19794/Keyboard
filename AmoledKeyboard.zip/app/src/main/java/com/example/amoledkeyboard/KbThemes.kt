package com.example.amoledkeyboard

import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build

object Prefs {
    fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("kb_prefs", Context.MODE_PRIVATE)
}

data class KbTheme(
    val name: String,
    val bg: Int,
    val key: Int,
    val func: Int,
    val funcOn: Int,
    val text: Int,
    val hint: Int
)

object KbThemes {
    private fun c(s: String) = Color.parseColor(s)

    fun themes(ctx: Context): List<KbTheme> {
        val l = mutableListOf(
            KbTheme("AMOLED", c("#000000"), c("#0B0B0B"), c("#151515"), c("#2E2E2E"), c("#FFFFFF"), c("#888888")),
            KbTheme("Graphite", c("#121212"), c("#1E1E20"), c("#2A2A2D"), c("#3A3A3E"), c("#F2F2F2"), c("#9A9AA0")),
            KbTheme("Midnight", c("#050B1A"), c("#0F1A33"), c("#16254A"), c("#22377A"), c("#E8EEFF"), c("#7F8DB5")),
            KbTheme("Forest", c("#04100A"), c("#0C1F14"), c("#12301F"), c("#1C4A2F"), c("#E6F4EA"), c("#7DA08A")),
            KbTheme("Plum", c("#0E0510"), c("#1C0B20"), c("#2A1130"), c("#421A4A"), c("#F6E8F9"), c("#A07FA8")),
            KbTheme("Paper", c("#F4F1EA"), c("#FFFFFF"), c("#E3DFD5"), c("#CFCABD"), c("#1A1A1A"), c("#7A7A7A"))
        )
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                fun col(id: Int) = ctx.getColor(id)
                if (isNight(ctx)) {
                    l.add(
                        KbTheme(
                            "You",
                            col(android.R.color.system_neutral1_900),
                            col(android.R.color.system_neutral2_800),
                            col(android.R.color.system_accent2_700),
                            col(android.R.color.system_accent2_600),
                            col(android.R.color.system_neutral1_50),
                            col(android.R.color.system_neutral2_300)
                        )
                    )
                } else {
                    l.add(
                        KbTheme(
                            "You",
                            col(android.R.color.system_neutral1_50),
                            col(android.R.color.system_neutral1_0),
                            col(android.R.color.system_accent2_100),
                            col(android.R.color.system_accent2_200),
                            col(android.R.color.system_neutral1_900),
                            col(android.R.color.system_neutral2_600)
                        )
                    )
                }
            } catch (e: Exception) {
                // Dynamic colors unavailable; skip this theme.
            }
        }
        return l
    }

    private fun isNight(ctx: Context): Boolean =
        (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES

    /** Material You ("You") is the default whenever the phone supports it. */
    fun defaultThemeIndex(ctx: Context): Int {
        val i = themes(ctx).indexOfFirst { it.name == "You" }
        return if (i < 0) 0 else i
    }

    fun defaultAccentIndex(ctx: Context): Int {
        val i = accents(ctx).indexOfFirst { it.first == "You" }
        return if (i < 0) 0 else i
    }

    fun accents(ctx: Context): List<Pair<String, Int>> {
        val l = mutableListOf(
            "Gold" to c("#CC9F00"),
            "Red" to c("#D71921"),
            "Mint" to c("#3DDC97"),
            "Sky" to c("#4FC3F7"),
            "Violet" to c("#B388FF"),
            "Peach" to c("#FF8A65"),
            "White" to c("#F2F2F2")
        )
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val id = if (isNight(ctx)) android.R.color.system_accent1_200 else android.R.color.system_accent1_600
                l.add("You" to ctx.getColor(id))
            } catch (e: Exception) {
                // Dynamic colors unavailable; skip.
            }
        }
        return l
    }

    /** Readable icon/text color on top of [bg]. */
    fun onColor(bg: Int): Int {
        val lum = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255.0
        return if (lum > 0.6) Color.parseColor("#141414") else Color.WHITE
    }
}
