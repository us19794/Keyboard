package com.example.amoledkeyboard

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.res.ResourcesCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var sp: SharedPreferences
    private lateinit var previewHost: FrameLayout
    private lateinit var micStatus: TextView

    private val gray = Color.parseColor("#9A9AA0")

    // Serif face for headings and subheadings (Caladea, bundled in res/font).
    private val serif: Typeface by lazy {
        ResourcesCompat.getFont(this, R.font.caladea_regular) ?: Typeface.SERIF
    }

    // Warm text color that follows the wallpaper (Material You).
    private val headingColor: Int by lazy {
        MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface, Color.WHITE)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        DynamicColors.applyToActivityIfAvailable(this)
        super.onCreate(savedInstanceState)
        sp = Prefs.sp(this)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(32))
        }
        scroll.addView(col)

        // Header
        col.addView(TextView(this).apply {
            text = "Keyboard"
            textSize = 52f
            setTextColor(headingColor)
            typeface = serif
            letterSpacing = -0.02f
        })
        col.addView(TextView(this).apply {
            text = "Make it yours."
            textSize = 20f
            setTextColor(gray)
            typeface = serif
            setPadding(0, 0, 0, dp(22))
        })

        // Setup
        section(col, "Get started", "Turn the keyboard on, then pick it.") {
            val buttons = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(14), 0, 0)
            }
            buttons.addView(MaterialButton(this@MainActivity).apply {
                text = "Enable"
                cornerRadius = dp(20)
                layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) }
                setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
            })
            buttons.addView(
                MaterialButton(
                    this@MainActivity, null,
                    com.google.android.material.R.attr.materialButtonOutlinedStyle
                ).apply {
                    text = "Switch"
                    cornerRadius = dp(20)
                    layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(8) }
                    setOnClickListener {
                        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                    }
                }
            )
            addView(buttons)
        }

        // Preview
        previewHost = FrameLayout(this)
        section(col, "Preview") {
            addView(previewHost, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) })
        }
        refreshPreview()

        // Try it
        section(col, "Try it") {
            addView(EditText(this@MainActivity).apply {
                hint = "Type here to test the keyboard"
                setHintTextColor(gray)
                setTextColor(Color.WHITE)
                minLines = 2
                gravity = Gravity.TOP
                setPadding(dp(18), dp(14), dp(18), dp(14))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1E1E21"))
                    cornerRadius = dp(20).toFloat()
                }
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) })
        }

        // Colors
        val themes = KbThemes.themes(this)
        val accents = KbThemes.accents(this)
        section(col, "Colors") {
            addView(caption("Keyboard color"))
            addView(swatchRow(themes.map { it.name }, themes.map { it.key }, "theme", KbThemes.defaultThemeIndex(this@MainActivity)))
            addView(caption("Emoji key & caps color"))
            addView(swatchRow(accents.map { it.first }, accents.map { it.second }, "accent", KbThemes.defaultAccentIndex(this@MainActivity)))
        }

        // Key font
        section(col, "Key font", "Pick the typeface for the letters and suggestions.") {
            addView(fontRow())
        }

        // Shape
        section(col, "Shape") {
            addView(sliderRow("Key roundness", "corner", 6f, 28f, 1f, 14) { "$it dp" })
            addView(sliderRow("Key height", "height", 40f, 64f, 1f, 52) { "$it dp" })
        }

        // Motion & feel
        section(col, "Motion & feel") {
            addView(sliderRow("Animation speed", "anim", 0f, 200f, 10f, 100) {
                if (it == 0) "Off" else String.format("%.1f×", it / 100f)
            })
            addView(switchRow("Haptic feedback", "Tiny vibration on every key", "haptics", true))
        }

        // Typing
        section(col, "Typing") {
            addView(switchRow("Autocorrect", "Fixes common typos like teh → the", "autocorrect", true))
            addView(switchRow("Suggestions", "Word suggestions above the keys", "suggest", true))
            addView(switchRow("Auto-capitalize", "Capital letter at the start of a sentence", "autocap", true))
            addView(switchRow(
                "Learn my words",
                "Remembers words you type to predict better. Stays on this phone and skips password fields.",
                "learn", true
            ))
            addView(
                MaterialButton(
                    this@MainActivity, null,
                    com.google.android.material.R.attr.materialButtonOutlinedStyle
                ).apply {
                    text = "Clear learned words"
                    cornerRadius = dp(20)
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
                    ).apply { topMargin = dp(14) }
                    setOnClickListener {
                        getSharedPreferences("kb_learn", Context.MODE_PRIVATE).edit().clear().apply()
                        sp.edit().putInt("learn_epoch", sp.getInt("learn_epoch", 0) + 1).apply()
                        Toast.makeText(this@MainActivity, "Learned words cleared", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        // Emoji
        section(col, "Emoji", "Every emoji, including all flags.") {
            addView(caption("Default skin tone"))
            addView(pillRow(
                listOf("Yellow", "Light", "Medium-light", "Medium", "Medium-dark", "Dark"),
                "skin", 0
            ))
            addView(note(
                "Emoji are drawn by your phone's own emoji font, so they always match your " +
                    "phone's current style, and new emoji show up automatically when Android adds them. " +
                    "You can also cycle the skin tone with the hand key in the emoji panel."
            ))
        }

        // Voice typing
        section(col, "Voice typing", "Tap the mic next to the suggestions and talk.") {
            addView(switchRow("Show mic button", "Adds a mic key beside the suggestions", "voice_on", true))
            addView(caption("Speech engine"))
            addView(pillRow(listOf("Phone", "Gemini", "Whisper"), "voice_engine", 0))
            addView(note(
                "Phone uses your phone's own speech service and needs no key. " +
                    "Gemini and Whisper send your recording to that provider over the internet."
            ))
            addView(caption("Gemini · free tier"))
            addView(field("Gemini API key", "gemini_key", "", true))
            addView(field("Model", "gemini_model", "gemini-flash-latest", false))
            addView(note(
                "Get a free key at aistudio.google.com/apikey. On the free tier Google may use " +
                    "your requests to improve its products, and rate limits apply."
            ))
            addView(caption("Whisper · free on Groq"))
            addView(field("Whisper API key", "whisper_key", "", true))
            addView(field("Endpoint", "whisper_url", "https://api.groq.com/openai/v1/audio/transcriptions", false))
            addView(field("Model", "whisper_model", "whisper-large-v3-turbo", false))
            addView(note(
                "Get a free key at console.groq.com. Any OpenAI-compatible Whisper endpoint " +
                    "(for example OpenAI) works if you change the endpoint and model."
            ))
            addView(caption("Microphone"))
            micStatus = TextView(this@MainActivity).apply {
                textSize = 14f
                setTextColor(gray)
            }
            addView(micStatus)
            addView(
                MaterialButton(
                    this@MainActivity, null,
                    com.google.android.material.R.attr.materialButtonOutlinedStyle
                ).apply {
                    text = "Allow microphone"
                    cornerRadius = dp(20)
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(48)
                    ).apply { topMargin = dp(10) }
                    setOnClickListener { askMic() }
                }
            )
        }

        setContentView(scroll)
        refreshMicStatus()
        if (intent?.getBooleanExtra("ask_mic", false) == true && !micGranted()) askMic()
    }

    // ---------- UI helpers ----------

    private fun section(parent: LinearLayout, title: String, sub: String? = null, body: LinearLayout.() -> Unit) {
        val card = MaterialCardView(this).apply {
            radius = dp(28).toFloat()
            setCardBackgroundColor(Color.parseColor("#141416"))
            cardElevation = 0f
            strokeWidth = 0
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(14) }
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(20))
        }
        inner.addView(TextView(this).apply {
            text = title
            textSize = 26f
            setTextColor(headingColor)
            typeface = serif
        })
        if (sub != null) {
            inner.addView(TextView(this).apply {
                text = sub
                textSize = 16f
                setTextColor(gray)
                typeface = serif
                setPadding(0, dp(2), 0, 0)
            })
        }
        inner.body()
        card.addView(inner)
        parent.addView(card)
    }

    private fun caption(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 17f
        setTextColor(gray)
        typeface = serif
        setPadding(0, dp(18), 0, dp(10))
    }

    private fun swatchRow(names: List<String>, colors: List<Int>, prefKey: String, def: Int): View {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scroll.addView(row)
        val circles = ArrayList<View>()

        fun paint() {
            val sel = sp.getInt(prefKey, def)
            circles.forEachIndexed { i, v ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colors[i])
                    setStroke(
                        if (i == sel) dp(3) else dp(1),
                        if (i == sel) Color.WHITE else Color.parseColor("#555555")
                    )
                }
            }
        }

        names.forEachIndexed { i, n ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, 0, dp(14), 0)
            }
            val c = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
                setOnClickListener {
                    sp.edit().putInt(prefKey, i).apply()
                    paint()
                    refreshPreview()
                }
            }
            circles.add(c)
            item.addView(c)
            item.addView(TextView(this).apply {
                text = n
                textSize = 11f
                setTextColor(gray)
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
            row.addView(item)
        }
        paint()
        return scroll
    }

    override fun onResume() {
        super.onResume()
        if (::micStatus.isInitialized) refreshMicStatus()
    }

    private fun micGranted() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun askMic() {
        if (micGranted()) {
            Toast.makeText(this, "Microphone already allowed", Toast.LENGTH_SHORT).show()
        } else {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
        }
    }

    private fun refreshMicStatus() {
        micStatus.text = if (micGranted()) "Microphone allowed ✓" else "Microphone not allowed yet"
    }

    private fun note(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(gray)
        setPadding(0, dp(10), 0, 0)
    }

    private fun field(hint: String, prefKey: String, def: String, secret: Boolean): EditText =
        EditText(this).apply {
            this.hint = hint
            setHintTextColor(gray)
            setTextColor(Color.WHITE)
            textSize = 15f
            isSingleLine = true
            inputType = if (secret) {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            } else {
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            }
            setText(sp.getString(prefKey, def))
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E1E21"))
                cornerRadius = dp(16).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    sp.edit().putString(prefKey, s?.toString() ?: "").apply()
                }
            })
        }

    private fun pillRow(names: List<String>, prefKey: String, def: Int): View {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(2), 0, 0)
        }
        scroll.addView(row)
        val pills = ArrayList<TextView>()

        fun paint() {
            val sel = sp.getInt(prefKey, def)
            pills.forEachIndexed { i, tv ->
                tv.background = GradientDrawable().apply {
                    setColor(if (i == sel) headingColor else Color.parseColor("#1E1E21"))
                    cornerRadius = dp(22).toFloat()
                }
                tv.setTextColor(if (i == sel) Color.parseColor("#141414") else Color.WHITE)
            }
        }

        names.forEachIndexed { i, n ->
            val tv = TextView(this).apply {
                text = n
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(12), dp(20), dp(12))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
                setOnClickListener {
                    sp.edit().putInt(prefKey, i).apply()
                    paint()
                }
            }
            pills.add(tv)
            row.addView(tv)
        }
        paint()
        return scroll
    }

    private fun fontRow(): View {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(14), 0, 0)
        }
        scroll.addView(row)
        val tiles = ArrayList<View>()

        fun paint() {
            val sel = sp.getInt("font", 0)
            tiles.forEachIndexed { i, v ->
                v.background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1E1E21"))
                    cornerRadius = dp(18).toFloat()
                    setStroke(
                        if (i == sel) dp(2) else dp(1),
                        if (i == sel) headingColor else Color.parseColor("#33FFFFFF")
                    )
                }
            }
        }

        KbFonts.names.forEachIndexed { i, n ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(8), dp(14), dp(8), dp(12))
                layoutParams = LinearLayout.LayoutParams(dp(84), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    marginEnd = dp(10)
                }
                setOnClickListener {
                    sp.edit().putInt("font", i).apply()
                    paint()
                    refreshPreview()
                }
            }
            tile.addView(TextView(this).apply {
                text = "Aa"
                textSize = 30f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                typeface = KbFonts.typeface(this@MainActivity, i)
            })
            tile.addView(TextView(this).apply {
                text = n
                textSize = 12f
                setTextColor(gray)
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            })
            tiles.add(tile)
            row.addView(tile)
        }
        paint()
        return scroll
    }

    private fun sliderRow(
        label: String, prefKey: String, lo: Float, hi: Float, step: Float, def: Int,
        fmt: (Int) -> String
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, 0)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val nameTv = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val valueTv = TextView(this).apply {
            textSize = 14f
            setTextColor(gray)
            text = fmt(sp.getInt(prefKey, def))
        }
        head.addView(nameTv)
        head.addView(valueTv)
        val slider = Slider(this).apply {
            valueFrom = lo
            valueTo = hi
            stepSize = step
            value = sp.getInt(prefKey, def).toFloat().coerceIn(lo, hi)
            addOnChangeListener { _, v, _ ->
                sp.edit().putInt(prefKey, v.toInt()).apply()
                valueTv.text = fmt(v.toInt())
                refreshPreview()
            }
        }
        box.addView(head)
        box.addView(slider)
        return box
    }

    private fun switchRow(title: String, sub: String, prefKey: String, def: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.WHITE)
        })
        texts.addView(TextView(this).apply {
            text = sub
            textSize = 13f
            setTextColor(gray)
        })
        val sw = MaterialSwitch(this).apply {
            isChecked = sp.getBoolean(prefKey, def)
            setOnCheckedChangeListener { _, checked ->
                sp.edit().putBoolean(prefKey, checked).apply()
            }
        }
        row.addView(texts)
        row.addView(sw)
        return row
    }

    // ---------- live preview ----------

    private fun refreshPreview() {
        val themes = KbThemes.themes(this)
        val th = themes[sp.getInt("theme", KbThemes.defaultThemeIndex(this)).coerceIn(0, themes.size - 1)]
        val accents = KbThemes.accents(this)
        val acc = accents[sp.getInt("accent", KbThemes.defaultAccentIndex(this)).coerceIn(0, accents.size - 1)].second
        val corner = sp.getInt("corner", 14)
        val keyH = sp.getInt("height", 52)

        previewHost.removeAllViews()
        previewHost.background = GradientDrawable().apply {
            setColor(th.bg)
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.parseColor("#2A2A2D"))
        }

        fun keyBox(content: View, bg: Int, weight: Float): FrameLayout = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(bg)
                cornerRadius = dp(corner).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(keyH), weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
            addView(content, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            ))
        }

        fun letterTv(t: String) = TextView(this).apply {
            text = t
            textSize = 20f
            setTextColor(th.text)
            typeface = KbFonts.typeface(this@MainActivity, sp.getInt("font", 0))
        }

        fun icon(type: NothingIcon.Type, tint: Int) = ImageView(this).apply {
            setImageDrawable(NothingIcon(type, tint, 0, dp(22)))
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(14), dp(8), dp(14))
        }
        row.addView(keyBox(icon(NothingIcon.Type.SHIFT, th.text), th.func, 1.3f))
        row.addView(keyBox(letterTv("a"), th.key, 1f))
        row.addView(keyBox(letterTv("b"), th.key, 1f))
        row.addView(keyBox(icon(NothingIcon.Type.EMOJI, KbThemes.onColor(acc)), acc, 1f))
        row.addView(keyBox(icon(NothingIcon.Type.BACKSPACE, th.text), th.func, 1.3f))
        previewHost.addView(row)
    }
}
