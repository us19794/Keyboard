package com.example.amoledkeyboard

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private lateinit var sp: SharedPreferences
    private lateinit var previewHost: FrameLayout

    private val gray = Color.parseColor("#9A9AA0")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sp = Prefs.sp(this)

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            isFillViewport = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(32))
        }
        scroll.addView(col)

        // Header
        col.addView(TextView(this).apply {
            text = "Keyboard"
            textSize = 44f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        col.addView(TextView(this).apply {
            text = "Make it yours."
            textSize = 18f
            setTextColor(gray)
            setPadding(0, 0, 0, dp(22))
        })

        // Setup
        section(col, "Get started", "Turn the keyboard on, then pick it.") {
            val buttons = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(14), 0, 0)
            }
            buttons.addView(MaterialButton(this@MainActivity).apply {
                text = "Enable"
                cornerRadius = dp(20)
                layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(8) }
                setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
            })
            buttons.addView(
                MaterialButton(
                    this@MainActivity, null,
                    com.google.android.material.R.attr.materialButtonOutlinedStyle
                ).apply {
                    text = "Switch"
                    cornerRadius = dp(20)
                    layoutParams = LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(8) }
                    setOnClickListener {
                        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
                    }
                }
            )
            addView(buttons)
        }

        // Preview
        previewHost = FrameLayout(this)
        section(col, "Preview") {
            addView(previewHost, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) })
        }
        refreshPreview()

        // Try it
        section(col, "Try it") {
            addView(EditText(this@MainActivity).apply {
                hint = "Type here to test the keyboard"
                setHintTextColor(gray)
                setTextColor(Color.WHITE)
                minLines = 2
                gravity = Gravity.TOP
                setPadding(dp(18), dp(14), dp(18), dp(14))
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#1E1E21"))
                    cornerRadius = dp(20).toFloat()
                }
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) })
        }

        // Colors
        val themes = KbThemes.themes(this)
        val accents = KbThemes.accents(this)
        section(col, "Colors") {
            addView(caption("Keyboard color"))
            addView(swatchRow(themes.map { it.name }, themes.map { it.key }, "theme"))
            addView(caption("Emoji key & caps color"))
            addView(swatchRow(accents.map { it.first }, accents.map { it.second }, "accent"))
        }

        // Shape
        section(col, "Shape") {
            addView(sliderRow("Key roundness", "corner", 6f, 28f, 1f, 14) { "$it dp" })
            addView(sliderRow("Key height", "height", 40f, 64f, 1f, 52) { "$it dp" })
        }

        // Motion & feel
        section(col, "Motion & feel") {
            addView(sliderRow("Animation speed", "anim", 0f, 200f, 10f, 100) {
                if (it == 0) "Off" else String.format("%.1f×", it / 100f)
            })
            addView(switchRow("Haptic feedback", "Tiny vibration on every key", "haptics", true))
        }

        // Typing
        section(col, "Typing") {
            addView(switchRow("Autocorrect", "Fixes common typos like teh → the", "autocorrect", true))
            addView(switchRow("Suggestions", "Word suggestions above the keys", "suggest", true))
            addView(switchRow("Auto-capitalize", "Capital letter at the start of a sentence", "autocap", true))
        }

        setContentView(scroll)
    }

    // ---------- UI helpers ----------

    private fun section(parent: LinearLayout, title: String, sub: String? = null, body: LinearLayout.() -> Unit) {
        val card = MaterialCardView(this).apply {
            radius = dp(28).toFloat()
            setCardBackgroundColor(Color.parseColor("#141416"))
            cardElevation = 0f
            strokeWidth = 0
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(14) }
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(20))
        }
        inner.addView(TextView(this).apply {
            text = title
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        if (sub != null) {
            inner.addView(TextView(this).apply {
                text = sub
                textSize = 14f
                setTextColor(gray)
                setPadding(0, dp(2), 0, 0)
            })
        }
        inner.body()
        card.addView(inner)
        parent.addView(card)
    }

    private fun caption(t: String): TextView = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(gray)
        setPadding(0, dp(18), 0, dp(10))
    }

    private fun swatchRow(names: List<String>, colors: List<Int>, prefKey: String): View {
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scroll.addView(row)
        val circles = ArrayList<View>()

        fun paint() {
            val sel = sp.getInt(prefKey, 0)
            circles.forEachIndexed { i, v ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colors[i])
                    setStroke(
                        if (i == sel) dp(3) else dp(1),
                        if (i == sel) Color.WHITE else Color.parseColor("#555555")
                    )
                }
            }
        }

        names.forEachIndexed { i, n ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(0, 0, dp(14), 0)
            }
            val c = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
                setOnClickListener {
                    sp.edit().putInt(prefKey, i).apply()
                    paint()
                    refreshPreview()
                }
            }
            circles.add(c)
            item.addView(c)
            item.addView(TextView(this).apply {
                text = n
                textSize = 11f
                setTextColor(gray)
                gravity = Gravity.CENTER
                setPadding(0, dp(6), 0, 0)
            })
            row.addView(item)
        }
        paint()
        return scroll
    }

    private fun sliderRow(
        label: String, prefKey: String, lo: Float, hi: Float, step: Float, def: Int,
        fmt: (Int) -> String
    ): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(16), 0, 0)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val nameTv = TextView(this).apply {
            text = label
            textSize = 16f
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val valueTv = TextView(this).apply {
            textSize = 14f
            setTextColor(gray)
            text = fmt(sp.getInt(prefKey, def))
        }
        head.addView(nameTv)
        head.addView(valueTv)
        val slider = Slider(this).apply {
            valueFrom = lo
            valueTo = hi
            stepSize = step
            value = sp.getInt(prefKey, def).toFloat().coerceIn(lo, hi)
            addOnChangeListener { _, v, _ ->
                sp.edit().putInt(prefKey, v.toInt()).apply()
                valueTv.text = fmt(v.toInt())
                refreshPreview()
            }
        }
        box.addView(head)
        box.addView(slider)
        return box
    }

    private fun switchRow(title: String, sub: String, prefKey: String, def: Boolean): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, 0)
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.WHITE)
        })
        texts.addView(TextView(this).apply {
            text = sub
            textSize = 13f
            setTextColor(gray)
        })
        val sw = MaterialSwitch(this).apply {
            isChecked = sp.getBoolean(prefKey, def)
            setOnCheckedChangeListener { _, checked ->
                sp.edit().putBoolean(prefKey, checked).apply()
            }
        }
        row.addView(texts)
        row.addView(sw)
        return row
    }

    // ---------- live preview ----------

    private fun refreshPreview() {
        val themes = KbThemes.themes(this)
        val th = themes[sp.getInt("theme", 0).coerceIn(0, themes.size - 1)]
        val accents = KbThemes.accents(this)
        val acc = accents[sp.getInt("accent", 0).coerceIn(0, accents.size - 1)].second
        val corner = sp.getInt("corner", 14)
        val keyH = sp.getInt("height", 52)

        previewHost.removeAllViews()
        previewHost.background = GradientDrawable().apply {
            setColor(th.bg)
            cornerRadius = dp(22).toFloat()
            setStroke(dp(1), Color.parseColor("#2A2A2D"))
        }

        fun keyBox(content: View, bg: Int, weight: Float): FrameLayout = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(bg)
                cornerRadius = dp(corner).toFloat()
            }
            layoutParams = LinearLayout.LayoutParams(0, dp(keyH), weight).apply {
                setMargins(dp(3), 0, dp(3), 0)
            }
            addView(content, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER
            ))
        }

        fun letterTv(t: String) = TextView(this).apply {
            text = t
            textSize = 20f
            setTextColor(th.text)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

        fun icon(type: NothingIcon.Type, tint: Int) = ImageView(this).apply {
            setImageDrawable(NothingIcon(type, tint, 0, dp(22)))
        }

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(8), dp(14), dp(8), dp(14))
        }
        row.addView(keyBox(icon(NothingIcon.Type.SHIFT, th.text), th.func, 1.3f))
        row.addView(keyBox(letterTv("a"), th.key, 1f))
        row.addView(keyBox(letterTv("b"), th.key, 1f))
        row.addView(keyBox(icon(NothingIcon.Type.EMOJI, KbThemes.onColor(acc)), acc, 1f))
        row.addView(keyBox(icon(NothingIcon.Type.BACKSPACE, th.text), th.func, 1.3f))
        previewHost.addView(row)
    }
}
