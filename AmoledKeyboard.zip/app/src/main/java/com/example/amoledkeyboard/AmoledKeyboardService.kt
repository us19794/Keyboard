package com.example.amoledkeyboard

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.WindowInsetsControllerCompat
import java.util.concurrent.Executors
import kotlin.math.abs

class AmoledKeyboardService : InputMethodService() {

    private enum class Page { LETTERS, SYMBOLS, EMOJI }
    private enum class VoiceState { IDLE, LISTENING, WORKING }

    // ----- settings (loaded from SharedPreferences) -----
    private lateinit var sp: SharedPreferences
    private lateinit var kt: KbTheme
    private var accent = Color.parseColor("#CC9F00")
    private var onAccent = Color.parseColor("#141414")
    private var corner = 14
    private var keyH = 52
    private var animPct = 100
    private var haptics = true
    private var autocorrect = true
    private var suggest = true
    private var autocap = true
    private var learnOn = true
    private var voiceOn = true
    private var keyFace: Typeface = Typeface.DEFAULT

    // ----- state -----
    private var page = Page.LETTERS
    private var shifted = false
    private var capsLock = false
    private var lastShiftTap = 0L
    private var currentWord = ""
    private var password = false

    private lateinit var root: LinearLayout
    private lateinit var keysHost: LinearLayout
    private lateinit var predictor: Predictor
    private val suggViews = ArrayList<TextView>()
    private val letterKeys = ArrayList<TextView>()
    private var shiftFrame: FrameLayout? = null
    private var shiftIv: ImageView? = null
    private var micFrame: FrameLayout? = null
    private var micIv: ImageView? = null

    private val handler = Handler(Looper.getMainLooper())
    private var repeater: Runnable? = null

    // ----- voice -----
    private var voiceState = VoiceState.IDLE
    private var voiceSession = 0
    private var voiceLead = ""
    private var recognizer: SpeechRecognizer? = null
    private val wavRecorder = WavRecorder()
    private val worker = Executors.newSingleThreadExecutor()
    private val autoStop = Runnable { if (voiceState == VoiceState.LISTENING) stopVoice() }

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        predictor = Predictor(this)
    }

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        applyPrefs()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        cancelVoice()
        page = Page.LETTERS
        capsLock = false
        password = isPasswordField(info)
        predictor.syncEpoch()
        if (::root.isInitialized) {
            loadPrefs()
            val caps = if (info != null) currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0 else 0
            shifted = autocap && caps != 0
            applyPrefs()
        }
        updateSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopRepeat()
        cancelVoice()
        predictor.save()
        super.onFinishInputView(finishingInput)
    }

    override fun onDestroy() {
        cancelVoice()
        predictor.save()
        super.onDestroy()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateSuggestions()
    }

    private fun isPasswordField(info: EditorInfo?): Boolean {
        if (info == null) return false
        val cls = info.inputType and InputType.TYPE_MASK_CLASS
        val v = info.inputType and InputType.TYPE_MASK_VARIATION
        return when (cls) {
            InputType.TYPE_CLASS_TEXT ->
                v == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    v == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    v == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD
            InputType.TYPE_CLASS_NUMBER -> v == InputType.TYPE_NUMBER_VARIATION_PASSWORD
            else -> false
        }
    }

    // ---------- prefs ----------

    private fun loadPrefs() {
        sp = Prefs.sp(this)
        val themes = KbThemes.themes(this)
        kt = themes[sp.getInt("theme", KbThemes.defaultThemeIndex(this)).coerceIn(0, themes.size - 1)]
        val accents = KbThemes.accents(this)
        accent = accents[sp.getInt("accent", KbThemes.defaultAccentIndex(this)).coerceIn(0, accents.size - 1)].second
        onAccent = KbThemes.onColor(accent)
        corner = sp.getInt("corner", 14)
        keyH = sp.getInt("height", 52)
        animPct = sp.getInt("anim", 100)
        haptics = sp.getBoolean("haptics", true)
        autocorrect = sp.getBoolean("autocorrect", true)
        suggest = sp.getBoolean("suggest", true)
        autocap = sp.getBoolean("autocap", true)
        learnOn = sp.getBoolean("learn", true)
        voiceOn = sp.getBoolean("voice_on", true)
        keyFace = KbFonts.typeface(this, sp.getInt("font", 0))
    }

    private fun applyPrefs() {
        loadPrefs()
        root.setBackgroundColor(kt.bg)
        root.setPadding(dp(4), dp(6), dp(4), dp(6))
        root.removeAllViews()
        suggViews.clear()
        micFrame = null
        micIv = null
        if (suggest || voiceOn) root.addView(buildSuggestionBar())
        keysHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysHost)
        buildPage()
        styleWindow()
    }

    // Make the strip under the keys (system navigation bar area) the same color as the keyboard.
    private fun styleWindow() {
        try {
            val w = window?.window ?: return
            w.setBackgroundDrawable(ColorDrawable(kt.bg))
            w.navigationBarColor = kt.bg
            if (Build.VERSION.SDK_INT >= 28) w.navigationBarDividerColor = kt.bg
            if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
            WindowInsetsControllerCompat(w, w.decorView).isAppearanceLightNavigationBars =
                KbThemes.onColor(kt.bg) != Color.WHITE
        } catch (e: Exception) {
            // Cosmetic only; ignore.
        }
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(msg: String) {
        Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun haptic(v: View) {
        if (haptics) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun press(v: View, down: Boolean) {
        val f = animPct / 100f
        v.animate().cancel()
        if (f <= 0f) {
            v.scaleX = 1f
            v.scaleY = 1f
            v.alpha = if (down) 0.6f else 1f
            return
        }
        if (down) {
            v.animate().scaleX(0.9f).scaleY(0.9f).alpha(0.75f)
                .setDuration((70 / f).toLong())
                .setInterpolator(DecelerateInterpolator())
                .start()
        } else {
            v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration((220 / f).toLong())
                .setInterpolator(OvershootInterpolator(2.2f))
                .start()
        }
    }

    private fun fadeIn(v: View) {
        val f = animPct / 100f
        if (f <= 0f) return
        v.alpha = 0f
        v.animate().alpha(1f).setDuration((160 / f).toLong()).start()
    }

    // ---------- building blocks ----------

    private fun frame(content: View, weight: Float, bg: Int): FrameLayout =
        FrameLayout(this).apply {
            background = rounded(bg, corner)
            layoutParams = LinearLayout.LayoutParams(0, dp(keyH), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            addView(
                content,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }

    private fun bindTouch(v: View, repeat: Boolean, onTap: () -> Unit) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    press(view, true)
                    haptic(view)
                    onTap()
                    if (repeat) startRepeat(onTap)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    press(view, false)
                    stopRepeat()
                }
            }
            true
        }
    }

    private fun label(text: String, size: Float, color: Int): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = size
        gravity = Gravity.CENTER
        typeface = keyFace
    }

    private fun textKey(
        text: String,
        weight: Float = 1f,
        bg: Int = kt.key,
        size: Float = 22f,
        color: Int = kt.text,
        onTap: () -> Unit
    ): FrameLayout {
        val f = frame(label(text, size, color), weight, bg)
        bindTouch(f, false, onTap)
        return f
    }

    private fun iconKey(
        type: NothingIcon.Type,
        weight: Float,
        bg: Int,
        tint: Int,
        repeat: Boolean = false,
        onTap: () -> Unit
    ): FrameLayout {
        val iv = ImageView(this).apply { setImageDrawable(NothingIcon(type, tint, 0, dp(24))) }
        val f = frame(iv, weight, bg)
        bindTouch(f, repeat, onTap)
        return f
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, weight)
    }

    private fun display(s: String) = if (shifted || capsLock) s.uppercase() else s.lowercase()

    private fun letter(c: Char): View {
        val tv = label(display(c.toString()), 22f, kt.text)
        letterKeys.add(tv)
        val f = frame(tv, 1f, kt.key)
        bindTouch(f, false) { typeChar(c) }
        return f
    }

    private fun plain(s: String): View = textKey(s) { commit(s) }

    private fun backspaceKey(): View =
        iconKey(NothingIcon.Type.BACKSPACE, 1.4f, kt.func, kt.text, repeat = true) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            updateSuggestions()
        }

    // Space bar: tap = space, slide left/right = move the cursor.
    private fun spaceKey(weight: Float): View {
        val f = frame(label("space", 15f, kt.hint), weight, kt.key)
        var lastStepX = 0f
        var moved = false
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastStepX = e.x
                    moved = false
                    press(v, true)
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    val step = dp(14).toFloat()
                    var dx = e.x - lastStepX
                    while (abs(dx) >= step) {
                        val right = dx > 0
                        sendDownUpKeyEvents(
                            if (right) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                        )
                        lastStepX += if (right) step else -step
                        dx = e.x - lastStepX
                        moved = true
                        if (haptics) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    press(v, false)
                    if (!moved) {
                        haptic(v)
                        separator(" ")
                    }
                }
                MotionEvent.ACTION_CANCEL -> press(v, false)
            }
            true
        }
        return f
    }

    private fun bottomRow(modeLabel: String, onMode: () -> Unit): LinearLayout = row(
        textKey(modeLabel, 1.2f, bg = kt.func, size = 16f) { onMode() },
        iconKey(NothingIcon.Type.EMOJI, 1f, accent, onAccent) { switchTo(Page.EMOJI) },
        textKey(",") { separator(",") },
        spaceKey(4.5f),
        textKey(".") { separator(".") },
        iconKey(NothingIcon.Type.ENTER, 1.8f, kt.func, kt.text) { enter() }
    )

    // ---------- suggestion bar (+ mic) ----------

    private fun buildSuggestionBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(6))
        }
        if (suggest) {
            for (i in 0 until 3) {
                val tv = label("", 17f, kt.text).apply {
                    isSingleLine = true
                    background = rounded(kt.key, corner + 6)
                    layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                    setOnClickListener { onSuggestionTap((it as TextView).text.toString()) }
                }
                suggViews.add(tv)
                bar.addView(tv)
                if (i < 2) {
                    bar.addView(TextView(this).apply {
                        text = "•"
                        textSize = 8f
                        setTextColor(kt.hint)
                        gravity = Gravity.CENTER
                        layoutParams = LinearLayout.LayoutParams(dp(20), dp(44))
                    })
                }
            }
        } else {
            bar.addView(spacer(1f))
        }
        if (voiceOn) bar.addView(buildMicKey())
        return bar
    }

    private fun buildMicKey(): FrameLayout {
        val iv = ImageView(this).apply {
            setImageDrawable(NothingIcon(NothingIcon.Type.MIC, kt.text, 0, dp(22)))
        }
        val f = FrameLayout(this).apply {
            background = rounded(kt.key, corner + 6)
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(44)).apply { marginStart = dp(6) }
            addView(
                iv,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }
        bindTouch(f, false) { onMicTap() }
        micFrame = f
        micIv = iv
        refreshMicLook()
        return f
    }

    private fun refreshMicLook() {
        val f = micFrame ?: return
        val iv = micIv ?: return
        val bg: Int
        val fg: Int
        when (voiceState) {
            VoiceState.LISTENING -> { bg = accent; fg = onAccent }
            VoiceState.WORKING -> { bg = kt.funcOn; fg = kt.text }
            VoiceState.IDLE -> { bg = kt.key; fg = kt.text }
        }
        f.background = rounded(bg, corner + 6)
        iv.setImageDrawable(
            NothingIcon(NothingIcon.Type.MIC, fg, if (voiceState == VoiceState.LISTENING) 1 else 0, dp(22))
        )
    }

    // ---------- pages ----------

    private fun switchTo(p: Page) {
        page = p
        buildPage()
        fadeIn(keysHost)
    }

    private fun buildPage() {
        keysHost.removeAllViews()
        letterKeys.clear()
        shiftFrame = null
        shiftIv = null
        when (page) {
            Page.LETTERS -> buildLetters()
            Page.SYMBOLS -> buildSymbols()
            Page.EMOJI -> buildEmoji()
        }
    }

    private fun buildLetters() {
        keysHost.addView(row(*"qwertyuiop".map { letter(it) }.toTypedArray()))
        keysHost.addView(row(spacer(0.5f), *"asdfghjkl".map { letter(it) }.toTypedArray(), spacer(0.5f)))

        val iv = ImageView(this).apply {
            setImageDrawable(NothingIcon(NothingIcon.Type.SHIFT, kt.text, 0, dp(24)))
        }
        val sf = frame(iv, 1.4f, kt.func)
        bindTouch(sf, false) { onShift() }
        shiftFrame = sf
        shiftIv = iv
        keysHost.addView(row(sf, *"zxcvbnm'".map { letter(it) }.toTypedArray(), backspaceKey()))
        keysHost.addView(bottomRow("123") { switchTo(Page.SYMBOLS) })
        refreshShiftLook()
    }

    private fun buildSymbols() {
        keysHost.addView(row(*"1234567890".map { plain(it.toString()) }.toTypedArray()))
        keysHost.addView(row(*"@#$%&-+()/".map { plain(it.toString()) }.toTypedArray()))
        keysHost.addView(row(*"_*\":;!?~".map { plain(it.toString()) }.toTypedArray(), backspaceKey()))
        keysHost.addView(bottomRow("ABC") { switchTo(Page.LETTERS) })
    }

    private fun buildEmoji() {
        val emojis = listOf(
            "😀", "😂", "😍", "🥰", "😎", "🤔", "😢", "😡", "👍", "👎",
            "🙏", "👏", "🔥", "❤️", "💔", "🎉", "✨", "💯", "😴", "🤝",
            "🙌", "👀", "😅", "😭", "🤣", "😉", "😊", "🥳", "🤯", "🙈"
        )
        for (r in 0 until 3) {
            keysHost.addView(row(*emojis.subList(r * 10, r * 10 + 10).map { e ->
                textKey(e, 1f, size = 20f) { commit(e) }
            }.toTypedArray()))
        }
        keysHost.addView(
            row(
                textKey("ABC", 1.6f, bg = kt.func, size = 16f) { switchTo(Page.LETTERS) },
                spaceKey(5f),
                backspaceKey()
            )
        )
    }

    // ---------- input logic ----------

    private fun typeChar(c: Char) {
        commit(display(c.toString()))
        if (shifted && !capsLock) {
            shifted = false
            refreshCase()
        }
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
        updateSuggestions()
    }

    private fun separator(s: String) {
        applyAutocorrect()
        learnCurrent()
        commit(s)
        if (autocap) autoCapCheck()
    }

    private fun enter() {
        applyAutocorrect()
        learnCurrent()
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
            if (autocap) autoCapCheck()
        }
    }

    private fun autoCapCheck() {
        if (capsLock || shifted) return
        val ic = currentInputConnection ?: return
        val t = currentInputEditorInfo?.inputType ?: 0
        if (ic.getCursorCapsMode(t) != 0) {
            shifted = true
            refreshCase()
        }
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350) {
            capsLock = true
            shifted = true
        } else if (capsLock) {
            capsLock = false
            shifted = false
        } else {
            shifted = !shifted
        }
        lastShiftTap = now
        refreshCase()
    }

    private fun refreshCase() {
        letterKeys.forEach { it.text = display(it.text.toString()) }
        refreshShiftLook()
    }

    private fun refreshShiftLook() {
        val st = if (capsLock) 2 else if (shifted) 1 else 0
        val bg = when (st) {
            2 -> accent
            1 -> kt.funcOn
            else -> kt.func
        }
        val ic = if (st == 2) onAccent else kt.text
        shiftFrame?.background = rounded(bg, corner)
        shiftIv?.setImageDrawable(NothingIcon(NothingIcon.Type.SHIFT, ic, st, dp(24)))
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeater?.let { handler.removeCallbacks(it) }
        repeater = null
    }

    // ---------- autocorrect ----------

    private fun applyAutocorrect() {
        if (!autocorrect || password) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(30, 0)?.toString() ?: return
        val word = before.takeLastWhile { it.isLetter() || it == '\'' }
        if (word.isEmpty()) return
        var fix = FIXES[word.lowercase()] ?: return
        if (!fix.first().isUpperCase()) {
            fix = when {
                word.length > 1 && word.all { it.isUpperCase() } -> fix.uppercase()
                word.first().isUpperCase() -> fix.replaceFirstChar { it.uppercase() }
                else -> fix
            }
        }
        if (fix == word) return
        ic.deleteSurroundingText(word.length, 0)
        ic.commitText(fix, 1)
    }

    // ---------- word prediction ----------

    /** The word before the one being typed, or null at the start of a sentence/field. */
    private fun prevWord(before: String, curLen: Int): String? {
        val rest = before.substring(0, before.length - curLen)
        if (!rest.endsWith(" ")) return null
        val trimmed = rest.trimEnd()
        if (trimmed.isEmpty()) return null
        val last = trimmed.last()
        if (last == '.' || last == '!' || last == '?') return null
        val w = trimmed.takeLastWhile { it.isLetter() || it == '\'' }
        return if (w.isEmpty()) null else w.lowercase()
    }

    private fun learnCurrent() {
        if (!learnOn || password) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: return
        val cur = before.takeLastWhile { it.isLetter() || it == '\'' }
        if (cur.length < 2) return
        predictor.learn(prevWord(before, cur.length), cur.lowercase())
    }

    private fun updateSuggestions() {
        if (suggViews.isEmpty() || voiceState != VoiceState.IDLE) return
        if (password) {
            suggViews.forEach { it.text = "" }
            currentWord = ""
            return
        }
        val before = currentInputConnection?.getTextBeforeCursor(60, 0)?.toString() ?: ""
        currentWord = before.takeLastWhile { it.isLetter() || it == '\'' }
        val prev = prevWord(before, currentWord.length)
        val raw: List<String> = if (currentWord.isEmpty()) {
            predictor.next(prev)
        } else {
            predictor.complete(currentWord, prev).ifEmpty { listOf(currentWord) }
        }
        val cap = if (currentWord.isEmpty()) {
            prev == null || shifted || capsLock
        } else {
            currentWord.first().isUpperCase()
        }
        val shown = raw.map { w ->
            var x = when {
                w == "i" -> "I"
                w.startsWith("i'") -> "I" + w.substring(1)
                else -> w
            }
            if (cap && x.isNotEmpty()) x = x.replaceFirstChar { c -> c.uppercase() }
            x
        }
        for (i in 0 until suggViews.size) {
            suggViews[i].text = shown.getOrNull(i) ?: ""
        }
    }

    private fun onSuggestionTap(s: String) {
        if (s.isEmpty() || voiceState != VoiceState.IDLE) return
        val ic = currentInputConnection ?: return
        if (!password && learnOn) {
            val before = ic.getTextBeforeCursor(60, 0)?.toString() ?: ""
            val cur = before.takeLastWhile { it.isLetter() || it == '\'' }
            if (s.length >= 2) predictor.learn(prevWord(before, cur.length), s.lowercase())
        }
        if (currentWord.isNotEmpty()) ic.deleteSurroundingText(currentWord.length, 0)
        ic.commitText("$s ", 1)
        updateSuggestions()
        if (autocap) autoCapCheck()
    }

    // ---------- voice typing ----------

    private fun onMicTap() {
        when (voiceState) {
            VoiceState.IDLE -> startVoice()
            VoiceState.LISTENING -> stopVoice()
            VoiceState.WORKING -> { }
        }
    }

    private fun leadSpace(): String {
        val c = currentInputConnection?.getTextBeforeCursor(1, 0)?.toString() ?: ""
        return if (c.isNotEmpty() && !c[0].isWhitespace() && c[0] !in "([{\"'") " " else ""
    }

    private fun startVoice() {
        if (password) {
            toast("Voice typing is off in password fields")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Allow the microphone first")
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        .putExtra("ask_mic", true)
                )
            } catch (e: Exception) {
                // ignore
            }
            return
        }
        voiceLead = leadSpace()
        when (sp.getInt("voice_engine", 0)) {
            1 -> {
                if (sp.getString("gemini_key", "").isNullOrBlank()) {
                    toast("Add your Gemini API key in the app")
                    return
                }
                startRecording()
            }
            2 -> {
                if (sp.getString("whisper_key", "").isNullOrBlank()) {
                    toast("Add your Whisper API key in the app")
                    return
                }
                startRecording()
            }
            else -> startSystemVoice()
        }
    }

    private fun setVoice(state: VoiceState) {
        voiceState = state
        refreshMicLook()
        if (suggViews.size == 3) {
            when (state) {
                VoiceState.LISTENING -> {
                    suggViews[0].text = ""
                    suggViews[1].text = "Listening…"
                    suggViews[2].text = ""
                }
                VoiceState.WORKING -> {
                    suggViews[0].text = ""
                    suggViews[1].text = "Transcribing…"
                    suggViews[2].text = ""
                }
                VoiceState.IDLE -> updateSuggestions()
            }
        }
    }

    private fun startRecording() {
        if (!wavRecorder.start()) {
            toast("Couldn't start the microphone")
            return
        }
        voiceSession++
        setVoice(VoiceState.LISTENING)
        handler.postDelayed(autoStop, 90_000)
    }

    private fun startSystemVoice() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("No speech service found on this phone")
            return
        }
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        voiceSession++
        val session = voiceSession
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                if (session == voiceSession && voiceState == VoiceState.LISTENING) setVoice(VoiceState.WORKING)
            }
            override fun onError(error: Int) {
                if (session != voiceSession) return
                currentInputConnection?.finishComposingText()
                endSystemVoice()
                if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    toast("Voice error ($error)")
                }
            }
            override fun onResults(results: Bundle?) {
                if (session != voiceSession) return
                val t = firstResult(results)
                if (t.isNotEmpty()) commitVoice(t) else currentInputConnection?.finishComposingText()
                endSystemVoice()
            }
            override fun onPartialResults(partialResults: Bundle?) {
                if (session != voiceSession) return
                val t = firstResult(partialResults)
                if (t.isNotEmpty()) currentInputConnection?.setComposingText(voiceLead + t, 1)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        setVoice(VoiceState.LISTENING)
        r.startListening(i)
    }

    private fun firstResult(b: Bundle?): String =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""

    private fun endSystemVoice() {
        val r = recognizer
        recognizer = null
        handler.post { try { r?.destroy() } catch (e: Exception) { } }
        setVoice(VoiceState.IDLE)
    }

    private fun stopVoice() {
        handler.removeCallbacks(autoStop)
        val engine = sp.getInt("voice_engine", 0)
        if (engine == 0) {
            setVoice(VoiceState.WORKING)
            recognizer?.stopListening()
            return
        }
        val wav = wavRecorder.stop()
        if (wav == null) {
            setVoice(VoiceState.IDLE)
            return
        }
        setVoice(VoiceState.WORKING)
        val session = voiceSession
        val gKey = sp.getString("gemini_key", "") ?: ""
        val gModel = sp.getString("gemini_model", "gemini-flash-latest") ?: "gemini-flash-latest"
        val wKey = sp.getString("whisper_key", "") ?: ""
        val wUrl = sp.getString("whisper_url", "https://api.groq.com/openai/v1/audio/transcriptions")
            ?: "https://api.groq.com/openai/v1/audio/transcriptions"
        val wModel = sp.getString("whisper_model", "whisper-large-v3-turbo") ?: "whisper-large-v3-turbo"
        worker.execute {
            var text = ""
            var err: String? = null
            try {
                text = if (engine == 1) Transcriber.gemini(gKey, gModel, wav)
                else Transcriber.whisper(wUrl, wKey, wModel, wav)
            } catch (e: Exception) {
                err = e.message ?: "network error"
            }
            handler.post {
                if (session == voiceSession) {
                    if (err != null) toast("Voice failed: $err")
                    else if (text.isNotEmpty()) commitVoice(text)
                    setVoice(VoiceState.IDLE)
                }
            }
        }
    }

    private fun commitVoice(text: String) {
        currentInputConnection?.commitText(voiceLead + text.trim() + " ", 1)
        updateSuggestions()
    }

    private fun cancelVoice() {
        voiceSession++
        handler.removeCallbacks(autoStop)
        val r = recognizer
        recognizer = null
        if (r != null) {
            try { r.cancel() } catch (e: Exception) { }
            try { r.destroy() } catch (e: Exception) { }
        }
        wavRecorder.cancel()
        voiceState = VoiceState.IDLE
        refreshMicLook()
    }

    companion object {
        private val FIXES: Map<String, String> = mapOf(
            "i" to "I", "im" to "I'm", "i'm" to "I'm", "ive" to "I've", "i've" to "I've",
            "i'll" to "I'll", "i'd" to "I'd",
            "dont" to "don't", "cant" to "can't", "wont" to "won't", "didnt" to "didn't",
            "doesnt" to "doesn't", "isnt" to "isn't", "wasnt" to "wasn't", "arent" to "aren't",
            "couldnt" to "couldn't", "shouldnt" to "shouldn't", "wouldnt" to "wouldn't",
            "havent" to "haven't", "hasnt" to "hasn't", "hadnt" to "hadn't", "werent" to "weren't",
            "youre" to "you're", "theyre" to "they're", "thats" to "that's", "whats" to "what's",
            "theres" to "there's", "hes" to "he's", "shes" to "she's", "youve" to "you've",
            "teh" to "the", "hte" to "the", "adn" to "and", "nad" to "and", "taht" to "that",
            "thier" to "their", "thsi" to "this", "tihs" to "this", "yuo" to "you", "yoru" to "your",
            "jsut" to "just", "wiht" to "with", "whith" to "with", "wich" to "which",
            "waht" to "what", "whta" to "what", "abuot" to "about", "aobut" to "about",
            "woudl" to "would", "coudl" to "could", "shoudl" to "should", "peopel" to "people",
            "becuase" to "because", "becasue" to "because", "beacuse" to "because",
            "ahve" to "have", "hvae" to "have", "haev" to "have", "thansk" to "thanks",
            "helo" to "hello", "alot" to "a lot", "untill" to "until",
            "recieve" to "receive", "wierd" to "weird", "definately" to "definitely",
            "definatly" to "definitely", "seperate" to "separate", "occured" to "occurred",
            "tommorow" to "tomorrow", "tomorow" to "tomorrow", "freind" to "friend",
            "beleive" to "believe", "acheive" to "achieve", "accomodate" to "accommodate",
            "adress" to "address", "beggining" to "beginning", "calender" to "calendar",
            "comming" to "coming", "existance" to "existence", "foriegn" to "foreign",
            "goverment" to "government", "grammer" to "grammar", "happend" to "happened",
            "immediatly" to "immediately", "independant" to "independent", "interupt" to "interrupt",
            "knowlege" to "knowledge", "maintainance" to "maintenance", "neccessary" to "necessary",
            "necesary" to "necessary", "noticable" to "noticeable", "occassion" to "occasion",
            "occurence" to "occurrence", "persistant" to "persistent", "posession" to "possession",
            "prefered" to "preferred", "publically" to "publicly", "realy" to "really",
            "recomend" to "recommend", "refered" to "referred", "relevent" to "relevant",
            "sucessful" to "successful", "succesful" to "successful", "suprise" to "surprise",
            "truely" to "truly", "unfortunatly" to "unfortunately", "writting" to "writing",
            "yeild" to "yield"
        )
    }
}
