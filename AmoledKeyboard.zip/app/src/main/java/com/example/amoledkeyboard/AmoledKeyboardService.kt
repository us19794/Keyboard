package com.example.amoledkeyboard

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.math.abs

class AmoledKeyboardService : InputMethodService() {

    private enum class Page { LETTERS, SYMBOLS, EMOJI }

    // ----- settings (loaded from SharedPreferences) -----
    private lateinit var sp: SharedPreferences
    private lateinit var kt: KbTheme
    private var accent = Color.parseColor("#CC9F00")
    private var onAccent = Color.parseColor("#141414")
    private var corner = 14
    private var keyH = 52
    private var animPct = 100
    private var haptics = true
    private var autocorrect = true
    private var suggest = true
    private var autocap = true

    // ----- state -----
    private var page = Page.LETTERS
    private var shifted = false
    private var capsLock = false
    private var lastShiftTap = 0L
    private var currentWord = ""

    private lateinit var root: LinearLayout
    private lateinit var keysHost: LinearLayout
    private val suggViews = ArrayList<TextView>()
    private val letterKeys = ArrayList<TextView>()
    private var shiftFrame: FrameLayout? = null
    private var shiftIv: ImageView? = null

    private val handler = Handler(Looper.getMainLooper())
    private var repeater: Runnable? = null

    // ---------- lifecycle ----------

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        applyPrefs()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        page = Page.LETTERS
        capsLock = false
        if (::root.isInitialized) {
            loadPrefs()
            val caps = if (info != null) currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0 else 0
            shifted = autocap && caps != 0
            applyPrefs()
        }
        updateSuggestions()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        stopRepeat()
        super.onFinishInputView(finishingInput)
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateSuggestions()
    }

    // ---------- prefs ----------

    private fun loadPrefs() {
        sp = Prefs.sp(this)
        val themes = KbThemes.themes(this)
        kt = themes[sp.getInt("theme", KbThemes.defaultThemeIndex(this)).coerceIn(0, themes.size - 1)]
        val accents = KbThemes.accents(this)
        accent = accents[sp.getInt("accent", KbThemes.defaultAccentIndex(this)).coerceIn(0, accents.size - 1)].second
        onAccent = KbThemes.onColor(accent)
        corner = sp.getInt("corner", 14)
        keyH = sp.getInt("height", 52)
        animPct = sp.getInt("anim", 100)
        haptics = sp.getBoolean("haptics", true)
        autocorrect = sp.getBoolean("autocorrect", true)
        suggest = sp.getBoolean("suggest", true)
        autocap = sp.getBoolean("autocap", true)
    }

    private fun applyPrefs() {
        loadPrefs()
        root.setBackgroundColor(kt.bg)
        root.setPadding(dp(4), dp(6), dp(4), dp(6))
        root.removeAllViews()
        suggViews.clear()
        if (suggest) root.addView(buildSuggestionBar())
        keysHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysHost)
        buildPage()
        styleWindow()
    }

    // Make the strip under the keys (system navigation bar area) the same color as the keyboard.
    private fun styleWindow() {
        try {
            val w = window?.window ?: return
            w.setBackgroundDrawable(ColorDrawable(kt.bg))
            w.navigationBarColor = kt.bg
            if (Build.VERSION.SDK_INT >= 28) w.navigationBarDividerColor = kt.bg
            if (Build.VERSION.SDK_INT >= 29) w.isNavigationBarContrastEnforced = false
            WindowInsetsControllerCompat(w, w.decorView).isAppearanceLightNavigationBars =
                KbThemes.onColor(kt.bg) != Color.WHITE
        } catch (e: Exception) {
            // Cosmetic only; ignore.
        }
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun haptic(v: View) {
        if (haptics) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
    }

    private fun press(v: View, down: Boolean) {
        val f = animPct / 100f
        v.animate().cancel()
        if (f <= 0f) {
            v.scaleX = 1f
            v.scaleY = 1f
            v.alpha = if (down) 0.6f else 1f
            return
        }
        if (down) {
            v.animate().scaleX(0.9f).scaleY(0.9f).alpha(0.75f)
                .setDuration((70 / f).toLong())
                .setInterpolator(DecelerateInterpolator())
                .start()
        } else {
            v.animate().scaleX(1f).scaleY(1f).alpha(1f)
                .setDuration((220 / f).toLong())
                .setInterpolator(OvershootInterpolator(2.2f))
                .start()
        }
    }

    private fun fadeIn(v: View) {
        val f = animPct / 100f
        if (f <= 0f) return
        v.alpha = 0f
        v.animate().alpha(1f).setDuration((160 / f).toLong()).start()
    }

    // ---------- building blocks ----------

    private fun frame(content: View, weight: Float, bg: Int): FrameLayout =
        FrameLayout(this).apply {
            background = rounded(bg, corner)
            layoutParams = LinearLayout.LayoutParams(0, dp(keyH), weight).apply {
                setMargins(dp(2), dp(3), dp(2), dp(3))
            }
            addView(
                content,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }

    private fun bindTouch(v: View, repeat: Boolean, onTap: () -> Unit) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    press(view, true)
                    haptic(view)
                    onTap()
                    if (repeat) startRepeat(onTap)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    press(view, false)
                    stopRepeat()
                }
            }
            true
        }
    }

    private fun label(text: String, size: Float, color: Int): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = size
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun textKey(
        text: String,
        weight: Float = 1f,
        bg: Int = kt.key,
        size: Float = 22f,
        color: Int = kt.text,
        onTap: () -> Unit
    ): FrameLayout {
        val f = frame(label(text, size, color), weight, bg)
        bindTouch(f, false, onTap)
        return f
    }

    private fun iconKey(
        type: NothingIcon.Type,
        weight: Float,
        bg: Int,
        tint: Int,
        repeat: Boolean = false,
        onTap: () -> Unit
    ): FrameLayout {
        val iv = ImageView(this).apply { setImageDrawable(NothingIcon(type, tint, 0, dp(24))) }
        val f = frame(iv, weight, bg)
        bindTouch(f, repeat, onTap)
        return f
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, weight)
    }

    private fun display(s: String) = if (shifted || capsLock) s.uppercase() else s.lowercase()

    private fun letter(c: Char): View {
        val tv = label(display(c.toString()), 22f, kt.text)
        letterKeys.add(tv)
        val f = frame(tv, 1f, kt.key)
        bindTouch(f, false) { typeChar(c) }
        return f
    }

    private fun plain(s: String): View = textKey(s) { commit(s) }

    private fun backspaceKey(): View =
        iconKey(NothingIcon.Type.BACKSPACE, 1.4f, kt.func, kt.text, repeat = true) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            updateSuggestions()
        }

    // Space bar: tap = space, slide left/right = move the cursor.
    private fun spaceKey(weight: Float): View {
        val f = frame(label("space", 15f, kt.hint), weight, kt.key)
        var lastStepX = 0f
        var moved = false
        f.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastStepX = e.x
                    moved = false
                    press(v, true)
                    v.parent?.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> {
                    val step = dp(14).toFloat()
                    var dx = e.x - lastStepX
                    while (abs(dx) >= step) {
                        val right = dx > 0
                        sendDownUpKeyEvents(
                            if (right) KeyEvent.KEYCODE_DPAD_RIGHT else KeyEvent.KEYCODE_DPAD_LEFT
                        )
                        lastStepX += if (right) step else -step
                        dx = e.x - lastStepX
                        moved = true
                        if (haptics) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    press(v, false)
                    if (!moved) {
                        haptic(v)
                        separator(" ")
                    }
                }
                MotionEvent.ACTION_CANCEL -> press(v, false)
            }
            true
        }
        return f
    }

    private fun bottomRow(modeLabel: String, onMode: () -> Unit): LinearLayout = row(
        textKey(modeLabel, 1.2f, bg = kt.func, size = 16f) { onMode() },
        iconKey(NothingIcon.Type.EMOJI, 1f, accent, onAccent) { switchTo(Page.EMOJI) },
        textKey(",") { separator(",") },
        spaceKey(4.5f),
        textKey(".") { separator(".") },
        iconKey(NothingIcon.Type.ENTER, 1.8f, kt.func, kt.text) { enter() }
    )

    // ---------- suggestion bar ----------

    private fun buildSuggestionBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(6))
        }
        for (i in 0 until 3) {
            val tv = label("", 17f, kt.text).apply {
                isSingleLine = true
                background = rounded(kt.key, corner + 6)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                setOnClickListener { onSuggestionTap((it as TextView).text.toString()) }
            }
            suggViews.add(tv)
            bar.addView(tv)
            if (i < 2) {
                bar.addView(TextView(this).apply {
                    text = "•"
                    textSize = 8f
                    setTextColor(kt.hint)
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(20), dp(44))
                })
            }
        }
        return bar
    }

    // ---------- pages ----------

    private fun switchTo(p: Page) {
        page = p
        buildPage()
        fadeIn(keysHost)
    }

    private fun buildPage() {
        keysHost.removeAllViews()
        letterKeys.clear()
        shiftFrame = null
        shiftIv = null
        when (page) {
            Page.LETTERS -> buildLetters()
            Page.SYMBOLS -> buildSymbols()
            Page.EMOJI -> buildEmoji()
        }
    }

    private fun buildLetters() {
        keysHost.addView(row(*"qwertyuiop".map { letter(it) }.toTypedArray()))
        keysHost.addView(row(spacer(0.5f), *"asdfghjkl".map { letter(it) }.toTypedArray(), spacer(0.5f)))

        val iv = ImageView(this).apply {
            setImageDrawable(NothingIcon(NothingIcon.Type.SHIFT, kt.text, 0, dp(24)))
        }
        val sf = frame(iv, 1.4f, kt.func)
        bindTouch(sf, false) { onShift() }
        shiftFrame = sf
        shiftIv = iv
        keysHost.addView(row(sf, *"zxcvbnm'".map { letter(it) }.toTypedArray(), backspaceKey()))
        keysHost.addView(bottomRow("123") { switchTo(Page.SYMBOLS) })
        refreshShiftLook()
    }

    private fun buildSymbols() {
        keysHost.addView(row(*"1234567890".map { plain(it.toString()) }.toTypedArray()))
        keysHost.addView(row(*"@#$%&-+()/".map { plain(it.toString()) }.toTypedArray()))
        keysHost.addView(row(*"_*\":;!?~".map { plain(it.toString()) }.toTypedArray(), backspaceKey()))
        keysHost.addView(bottomRow("ABC") { switchTo(Page.LETTERS) })
    }

    private fun buildEmoji() {
        val emojis = listOf(
            "😀", "😂", "😍", "🥰", "😎", "🤔", "😢", "😡", "👍", "👎",
            "🙏", "👏", "🔥", "❤️", "💔", "🎉", "✨", "💯", "😴", "🤝",
            "🙌", "👀", "😅", "😭", "🤣", "😉", "😊", "🥳", "🤯", "🙈"
        )
        for (r in 0 until 3) {
            keysHost.addView(row(*emojis.subList(r * 10, r * 10 + 10).map { e ->
                textKey(e, 1f, size = 20f) { commit(e) }
            }.toTypedArray()))
        }
        keysHost.addView(
            row(
                textKey("ABC", 1.6f, bg = kt.func, size = 16f) { switchTo(Page.LETTERS) },
                spaceKey(5f),
                backspaceKey()
            )
        )
    }

    // ---------- input logic ----------

    private fun typeChar(c: Char) {
        commit(display(c.toString()))
        if (shifted && !capsLock) {
            shifted = false
            refreshCase()
        }
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
        updateSuggestions()
    }

    private fun separator(s: String) {
        applyAutocorrect()
        commit(s)
        if (autocap) autoCapCheck()
    }

    private fun enter() {
        applyAutocorrect()
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val opts = ei?.imeOptions ?: 0
        val action = opts and EditorInfo.IME_MASK_ACTION
        val noAction = (opts and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
            if (autocap) autoCapCheck()
        }
    }

    private fun autoCapCheck() {
        if (capsLock || shifted) return
        val ic = currentInputConnection ?: return
        val t = currentInputEditorInfo?.inputType ?: 0
        if (ic.getCursorCapsMode(t) != 0) {
            shifted = true
            refreshCase()
        }
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350) {
            capsLock = true
            shifted = true
        } else if (capsLock) {
            capsLock = false
            shifted = false
        } else {
            shifted = !shifted
        }
        lastShiftTap = now
        refreshCase()
    }

    private fun refreshCase() {
        letterKeys.forEach { it.text = display(it.text.toString()) }
        refreshShiftLook()
    }

    private fun refreshShiftLook() {
        val st = if (capsLock) 2 else if (shifted) 1 else 0
        val bg = when (st) {
            2 -> accent
            1 -> kt.funcOn
            else -> kt.func
        }
        val ic = if (st == 2) onAccent else kt.text
        shiftFrame?.background = rounded(bg, corner)
        shiftIv?.setImageDrawable(NothingIcon(NothingIcon.Type.SHIFT, ic, st, dp(24)))
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeater?.let { handler.removeCallbacks(it) }
        repeater = null
    }

    // ---------- autocorrect ----------

    private fun applyAutocorrect() {
        if (!autocorrect) return
        val ic = currentInputConnection ?: return
        val before = ic.getTextBeforeCursor(30, 0)?.toString() ?: return
        val word = before.takeLastWhile { it.isLetter() || it == '\'' }
        if (word.isEmpty()) return
        var fix = FIXES[word.lowercase()] ?: return
        if (!fix.first().isUpperCase()) {
            fix = when {
                word.length > 1 && word.all { it.isUpperCase() } -> fix.uppercase()
                word.first().isUpperCase() -> fix.replaceFirstChar { it.uppercase() }
                else -> fix
            }
        }
        if (fix == word) return
        ic.deleteSurroundingText(word.length, 0)
        ic.commitText(fix, 1)
    }

    // ---------- suggestions ----------

    private fun updateSuggestions() {
        if (suggViews.isEmpty()) return
        val before = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString() ?: ""
        currentWord = before.takeLastWhile { it.isLetter() || it == '\'' }
        val options: List<String> = if (currentWord.isEmpty()) {
            listOf("I", "You", "The")
        } else {
            val upperFirst = currentWord.first().isUpperCase()
            val matches = WORDS.filter {
                it.startsWith(currentWord, ignoreCase = true) && !it.equals(currentWord, ignoreCase = true)
            }.take(3)
            val list = if (matches.isEmpty()) listOf(currentWord) else matches
            list.map { if (upperFirst) it.replaceFirstChar { c -> c.uppercase() } else it }
        }
        for (i in 0 until 3) {
            suggViews[i].text = options.getOrNull(i) ?: ""
        }
    }

    private fun onSuggestionTap(s: String) {
        if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        if (currentWord.isNotEmpty()) ic.deleteSurroundingText(currentWord.length, 0)
        ic.commitText("$s ", 1)
        updateSuggestions()
        if (autocap) autoCapCheck()
    }

    companion object {
        private val FIXES: Map<String, String> = mapOf(
            "i" to "I", "im" to "I'm", "i'm" to "I'm", "ive" to "I've", "i've" to "I've",
            "i'll" to "I'll", "i'd" to "I'd",
            "dont" to "don't", "cant" to "can't", "wont" to "won't", "didnt" to "didn't",
            "doesnt" to "doesn't", "isnt" to "isn't", "wasnt" to "wasn't", "arent" to "aren't",
            "couldnt" to "couldn't", "shouldnt" to "shouldn't", "wouldnt" to "wouldn't",
            "havent" to "haven't", "hasnt" to "hasn't", "hadnt" to "hadn't", "werent" to "weren't",
            "youre" to "you're", "theyre" to "they're", "thats" to "that's", "whats" to "what's",
            "theres" to "there's", "hes" to "he's", "shes" to "she's", "youve" to "you've",
            "teh" to "the", "hte" to "the", "adn" to "and", "nad" to "and", "taht" to "that",
            "thier" to "their", "thsi" to "this", "tihs" to "this", "yuo" to "you", "yoru" to "your",
            "jsut" to "just", "wiht" to "with", "whith" to "with", "wich" to "which",
            "waht" to "what", "whta" to "what", "abuot" to "about", "aobut" to "about",
            "woudl" to "would", "coudl" to "could", "shoudl" to "should", "peopel" to "people",
            "becuase" to "because", "becasue" to "because", "beacuse" to "because",
            "ahve" to "have", "hvae" to "have", "haev" to "have", "thansk" to "thanks",
            "helo" to "hello", "alot" to "a lot", "untill" to "until",
            "recieve" to "receive", "wierd" to "weird", "definately" to "definitely",
            "definatly" to "definitely", "seperate" to "separate", "occured" to "occurred",
            "tommorow" to "tomorrow", "tomorow" to "tomorrow", "freind" to "friend",
            "beleive" to "believe", "acheive" to "achieve", "accomodate" to "accommodate",
            "adress" to "address", "beggining" to "beginning", "calender" to "calendar",
            "comming" to "coming", "existance" to "existence", "foriegn" to "foreign",
            "goverment" to "government", "grammer" to "grammar", "happend" to "happened",
            "immediatly" to "immediately", "independant" to "independent", "interupt" to "interrupt",
            "knowlege" to "knowledge", "maintainance" to "maintenance", "neccessary" to "necessary",
            "necesary" to "necessary", "noticable" to "noticeable", "occassion" to "occasion",
            "occurence" to "occurrence", "persistant" to "persistent", "posession" to "possession",
            "prefered" to "preferred", "publically" to "publicly", "realy" to "really",
            "recomend" to "recommend", "refered" to "referred", "relevent" to "relevant",
            "sucessful" to "successful", "succesful" to "successful", "suprise" to "surprise",
            "truely" to "truly", "unfortunatly" to "unfortunately", "writting" to "writing",
            "yeild" to "yield"
        )

        private val WORDS = listOf(
            "about", "above", "after", "again", "all", "also", "always", "am", "and", "any",
            "are", "around", "as", "ask", "at", "away", "back", "be", "because", "been",
            "before", "being", "best", "better", "between", "big", "but", "by", "call", "came",
            "can", "come", "could", "day", "did", "do", "does", "done", "don't", "down",
            "each", "even", "every", "feel", "find", "first", "for", "from", "get", "give",
            "go", "going", "good", "got", "great", "had", "has", "have", "he", "hello",
            "help", "her", "here", "hey", "him", "his", "home", "how", "I", "I'm",
            "if", "in", "into", "is", "it", "it's", "just", "keep", "know", "last",
            "later", "let", "like", "little", "long", "look", "love", "make", "many", "maybe",
            "me", "more", "most", "much", "my", "need", "never", "new", "next", "no",
            "not", "now", "of", "off", "okay", "on", "one", "only", "or", "other",
            "our", "out", "over", "people", "please", "really", "right", "said", "same", "say",
            "see", "she", "should", "so", "some", "something", "sorry", "still", "sure", "take",
            "tell", "thank", "thanks", "that", "the", "their", "them", "then", "there", "they",
            "thing", "think", "this", "time", "to", "today", "tomorrow", "tonight", "too", "try",
            "up", "us", "use", "very", "want", "was", "way", "we", "well", "went",
            "were", "what", "when", "where", "which", "who", "why", "will", "with", "work",
            "would", "yes", "you", "your", "you're"
        )
    }
}
