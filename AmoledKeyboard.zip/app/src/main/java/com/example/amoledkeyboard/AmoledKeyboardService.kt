package com.example.amoledkeyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView

class AmoledKeyboardService : InputMethodService() {

    private enum class Page { LETTERS, SYMBOLS, EMOJI }

    // Colors (inspired by the reference screenshot)
    private val colBg = Color.BLACK
    private val colKey = Color.parseColor("#0B0B0B")
    private val colFunc = Color.parseColor("#151515")
    private val colFuncOn = Color.parseColor("#2E2E2E")
    private val colGold = Color.parseColor("#CC9F00")
    private val colText = Color.WHITE
    private val colHint = Color.parseColor("#888888")

    private var page = Page.LETTERS
    private var shifted = false
    private var capsLock = false
    private var lastShiftTap = 0L

    private lateinit var keysHost: LinearLayout
    private val suggViews = ArrayList<TextView>()
    private val letterKeys = ArrayList<TextView>()
    private var shiftKey: TextView? = null
    private var currentWord = ""

    private val handler = Handler(Looper.getMainLooper())
    private var repeater: Runnable? = null

    // ---------- lifecycle ----------

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(colBg)
            setPadding(dp(4), dp(6), dp(4), dp(10))
        }
        root.addView(buildSuggestionBar())
        keysHost = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(keysHost)
        root.addView(buildBottomBar())
        buildPage()
        return root
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        page = Page.LETTERS
        capsLock = false
        val caps = if (info != null) currentInputConnection?.getCursorCapsMode(info.inputType) ?: 0 else 0
        shifted = caps != 0
        if (::keysHost.isInitialized) buildPage()
        updateSuggestions()
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateSuggestions()
    }

    // ---------- UI building ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildSuggestionBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(6))
        }
        suggViews.clear()
        for (i in 0 until 3) {
            val tv = TextView(this).apply {
                setTextColor(colText)
                textSize = 17f
                gravity = Gravity.CENTER
                isSingleLine = true
                background = rounded(colKey, 20)
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f)
                setOnClickListener { onSuggestionTap(text.toString()) }
            }
            suggViews.add(tv)
            bar.addView(tv)
            if (i < 2) {
                bar.addView(TextView(this).apply {
                    text = "|"
                    setTextColor(colHint)
                    gravity = Gravity.CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(24), dp(44))
                })
            }
        }
        return bar
    }

    private fun buildBottomBar(): LinearLayout {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun icon(label: String, onTap: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(colText)
            textSize = 22f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(dp(64), dp(40))
            setOnClickListener { onTap() }
        }
        bar.addView(icon("⌄") { requestHideSelf(0) })
        bar.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(0, 1, 1f) })
        bar.addView(icon("🌐") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        return bar
    }

    private fun rounded(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    private fun key(
        label: String,
        weight: Float,
        bg: Int = colKey,
        textColor: Int = colText,
        size: Float = 22f,
        repeat: Boolean = false,
        onTap: () -> Unit
    ): TextView = TextView(this).apply {
        text = label
        setTextColor(textColor)
        textSize = size
        gravity = Gravity.CENTER
        background = rounded(bg, 14)
        layoutParams = LinearLayout.LayoutParams(0, dp(52), weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    v.alpha = 0.45f
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    onTap()
                    if (repeat) startRepeat(onTap)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.alpha = 1f
                    stopRepeat()
                }
            }
            true
        }
    }

    private fun row(vararg views: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    private fun spacer(weight: Float) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(0, 1, weight)
    }

    private fun letter(c: Char): TextView {
        val k = key(display(c.toString()), 1f) { typeChar(c) }
        letterKeys.add(k)
        return k
    }

    private fun display(s: String) = if (shifted || capsLock) s.uppercase() else s.lowercase()

    private fun buildPage() {
        keysHost.removeAllViews()
        letterKeys.clear()
        shiftKey = null
        when (page) {
            Page.LETTERS -> buildLetters()
            Page.SYMBOLS -> buildSymbols()
            Page.EMOJI -> buildEmoji()
        }
    }

    private fun buildLetters() {
        keysHost.addView(row(*"qwertyuiop".map { letter(it) }.toTypedArray()))
        keysHost.addView(row(spacer(0.5f), *"asdfghjkl".map { letter(it) }.toTypedArray(), spacer(0.5f)))
        val shift = key("⇧", 1.4f, bg = colFunc, size = 24f) { onShift() }
        shiftKey = shift
        keysHost.addView(
            row(shift, *"zxcvbnm'".map { letter(it) }.toTypedArray(), backspaceKey())
        )
        keysHost.addView(bottomRow("123") { page = Page.SYMBOLS; buildPage() })
        refreshShiftLook()
    }

    private fun buildSymbols() {
        keysHost.addView(row(*"1234567890".map { plain(it.toString()) }.toTypedArray()))
        keysHost.addView(row(*"@#$%&-+()/".map { plain(it.toString()) }.toTypedArray()))
        keysHost.addView(row(*"_*\":;!?~".map { plain(it.toString()) }.toTypedArray(), backspaceKey()))
        keysHost.addView(bottomRow("ABC") { page = Page.LETTERS; buildPage() })
    }

    private fun buildEmoji() {
        val emojis = listOf(
            "😀", "😂", "😍", "🥰", "😎", "🤔", "😢", "😡", "👍", "👎",
            "🙏", "👏", "🔥", "❤️", "💔", "🎉", "✨", "💯", "😴", "🤝",
            "🙌", "👀", "😅", "😭", "🤣", "😉", "😊", "🥳", "🤯", "🙈"
        )
        for (r in 0 until 3) {
            keysHost.addView(row(*emojis.subList(r * 10, r * 10 + 10).map { e ->
                key(e, 1f, size = 20f) { commit(e) }
            }.toTypedArray()))
        }
        keysHost.addView(
            row(
                key("ABC", 1.6f, bg = colFunc, size = 16f) { page = Page.LETTERS; buildPage() },
                key("space", 5f, textColor = colHint, size = 16f) { commit(" ") },
                backspaceKey()
            )
        )
    }

    private fun plain(s: String) = key(s, 1f) { commit(s) }

    private fun backspaceKey() = key("⌫", 1.4f, bg = colFunc, size = 22f, repeat = true) {
        sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        updateSuggestions()
    }

    private fun bottomRow(modeLabel: String, onMode: () -> Unit): LinearLayout = row(
        key(modeLabel, 1.2f, bg = colFunc, size = 16f) { onMode() },
        key("☺", 1f, bg = colGold, textColor = Color.parseColor("#1A1A1A"), size = 22f) {
            page = Page.EMOJI; buildPage()
        },
        key(",", 1f) { commit(",") },
        key("space", 4.5f, textColor = colHint, size = 16f) { commit(" ") },
        key(".", 1f) { commit(".") },
        key("↵", 1.8f, bg = colFunc, size = 24f) { enter() }
    )

    // ---------- input logic ----------

    private fun typeChar(c: Char) {
        commit(display(c.toString()))
        if (shifted && !capsLock) {
            shifted = false
            refreshCase()
        }
    }

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
        updateSuggestions()
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val action = (ei?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        val noAction = ((ei?.imeOptions ?: 0) and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
        if (!noAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.commitText("\n", 1)
        }
    }

    private fun onShift() {
        val now = System.currentTimeMillis()
        if (now - lastShiftTap < 350) {
            capsLock = true
            shifted = true
        } else if (capsLock) {
            capsLock = false
            shifted = false
        } else {
            shifted = !shifted
        }
        lastShiftTap = now
        refreshCase()
    }

    private fun refreshCase() {
        letterKeys.forEach { it.text = display(it.text.toString()) }
        refreshShiftLook()
    }

    private fun refreshShiftLook() {
        val k = shiftKey ?: return
        k.background = rounded(
            when {
                capsLock -> colGold
                shifted -> colFuncOn
                else -> colFunc
            }, 14
        )
        k.setTextColor(if (capsLock) Color.parseColor("#1A1A1A") else colText)
    }

    private fun startRepeat(action: () -> Unit) {
        stopRepeat()
        val r = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 50)
            }
        }
        repeater = r
        handler.postDelayed(r, 400)
    }

    private fun stopRepeat() {
        repeater?.let { handler.removeCallbacks(it) }
        repeater = null
    }

    // ---------- suggestions ----------

    private fun updateSuggestions() {
        if (suggViews.isEmpty()) return
        val before = currentInputConnection?.getTextBeforeCursor(30, 0)?.toString() ?: ""
        currentWord = before.takeLastWhile { it.isLetter() || it == '\'' }
        val options: List<String> = if (currentWord.isEmpty()) {
            listOf("I", "You", "The")
        } else {
            val lower = currentWord.lowercase()
            val upperFirst = currentWord.first().isUpperCase()
            val matches = WORDS.filter { it.startsWith(lower) && it != lower }.take(3)
            val list = if (matches.isEmpty()) listOf(currentWord) else matches
            list.map { if (upperFirst) it.replaceFirstChar { c -> c.uppercase() } else it }
        }
        for (i in 0 until 3) {
            suggViews[i].text = options.getOrNull(i) ?: ""
        }
    }

    private fun onSuggestionTap(s: String) {
        if (s.isEmpty()) return
        val ic = currentInputConnection ?: return
        if (currentWord.isNotEmpty()) ic.deleteSurroundingText(currentWord.length, 0)
        ic.commitText("$s ", 1)
        updateSuggestions()
    }

    companion object {
        private val WORDS = listOf(
            "about", "above", "after", "again", "all", "also", "always", "am", "and", "any",
            "are", "around", "as", "ask", "at", "away", "back", "be", "because", "been",
            "before", "being", "best", "better", "between", "big", "but", "by", "call", "came",
            "can", "come", "could", "day", "did", "do", "does", "done", "don't", "down",
            "each", "even", "every", "feel", "find", "first", "for", "from", "get", "give",
            "go", "going", "good", "got", "great", "had", "has", "have", "he", "hello",
            "help", "her", "here", "hey", "him", "his", "home", "how", "I", "I'm",
            "if", "in", "into", "is", "it", "it's", "just", "keep", "know", "last",
            "later", "let", "like", "little", "long", "look", "love", "make", "many", "maybe",
            "me", "more", "most", "much", "my", "need", "never", "new", "next", "no",
            "not", "now", "of", "off", "okay", "on", "one", "only", "or", "other",
            "our", "out", "over", "people", "please", "really", "right", "said", "same", "say",
            "see", "she", "should", "so", "some", "something", "sorry", "still", "sure", "take",
            "tell", "thank", "thanks", "that", "the", "their", "them", "then", "there", "they",
            "thing", "think", "this", "time", "to", "today", "tomorrow", "tonight", "too", "try",
            "up", "us", "use", "very", "want", "was", "way", "we", "well", "went",
            "were", "what", "when", "where", "which", "who", "why", "will", "with", "work",
            "would", "yes", "you", "your", "you're"
        )
    }
}
