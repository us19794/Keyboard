package com.example.amoledkeyboard

import android.graphics.Paint
import android.icu.lang.UCharacter
import android.icu.lang.UProperty
import android.icu.text.UnicodeSet
import android.os.Build

class EmojiItem(val base: String, val cat: Int, val canTone: Boolean) {
    private val toned = arrayOfNulls<String>(6)

    @Synchronized
    fun shown(tone: Int, paint: Paint): String {
        if (tone <= 0 || tone > 5 || !canTone) return base
        toned[tone]?.let { return it }
        val t = EmojiRepo.applyTone(base, tone)
        val r = if (t != base && paint.hasGlyph(t)) t else base
        toned[tone] = r
        return r
    }
}

/**
 * Every emoji the phone knows about. The list comes from the phone's own Unicode data (ICU)
 * and is checked against the phone's emoji font, so new emoji appear automatically and they
 * are always drawn in the phone's own emoji style.
 */
object EmojiRepo {
    val tabIcons = listOf("😀", "👋", "🐻", "🍔", "⚽", "🚗", "💡", "🔣", "🏁")

    private const val SMILEYS = 0
    private const val PEOPLE = 1
    private const val ANIMALS = 2
    private const val FOOD = 3
    private const val ACTIVITIES = 4
    private const val TRAVEL = 5
    private const val OBJECTS = 6
    private const val SYMBOLS = 7
    private const val FLAGS = 8

    private val paint = Paint()
    private var items: List<EmojiItem> = emptyList()
    @Volatile var ready = false

    // pairs of (first, last) code points
    private val R_FLAGS = intArrayOf(
        0x1F1E6, 0x1F1FF, 0x1F3F3, 0x1F3F4, 0x1F6A9, 0x1F6A9, 0x1F38C, 0x1F38C, 0x1F3C1, 0x1F3C1
    )
    private val R_SMILEYS = intArrayOf(
        0x1F600, 0x1F644, 0x1F648, 0x1F64A, 0x1F910, 0x1F915, 0x1F917, 0x1F917, 0x1F920, 0x1F925,
        0x1F927, 0x1F92F, 0x1F916, 0x1F916, 0x1F970, 0x1F97A, 0x1F9D0, 0x1F9D0, 0x1FAE0, 0x1FAEA,
        0x263A, 0x263A, 0x2639, 0x2639, 0x2620, 0x2620, 0x1F479, 0x1F47B, 0x1F47D, 0x1F47F,
        0x1F480, 0x1F480, 0x1F48B, 0x1F48C, 0x1F493, 0x1F49F, 0x1F4A2, 0x1F4A2, 0x1F4A4, 0x1F4A6,
        0x1F4A8, 0x1F4A9, 0x1F4AB, 0x1F4AD, 0x1F5A4, 0x1F5A4, 0x1F90D, 0x1F90E, 0x1F9E1, 0x1F9E1,
        0x2763, 0x2764, 0x1F5E8, 0x1F5E8, 0x1F5EF, 0x1F5EF, 0x1F573, 0x1F573
    )
    private val R_PEOPLE = intArrayOf(
        0x1F385, 0x1F385, 0x1F3C2, 0x1F3C4, 0x1F3C7, 0x1F3C7, 0x1F3CA, 0x1F3CC, 0x1F440, 0x1F450,
        0x1F463, 0x1F478, 0x1F47C, 0x1F47C, 0x1F481, 0x1F483, 0x1F485, 0x1F487, 0x1F4AA, 0x1F4AA,
        0x1F574, 0x1F57A, 0x1F590, 0x1F590, 0x1F595, 0x1F596, 0x1F645, 0x1F64F, 0x1F6A3, 0x1F6A3,
        0x1F6B4, 0x1F6B6, 0x1F6C0, 0x1F6C0, 0x1F6CC, 0x1F6CC, 0x1F90C, 0x1F90C, 0x1F90F, 0x1F90F,
        0x1F918, 0x1F91F, 0x1F926, 0x1F926, 0x1F930, 0x1F939, 0x1F93C, 0x1F93E, 0x1F9B0, 0x1F9B9,
        0x1F9BB, 0x1F9BB, 0x1F9BE, 0x1F9BF, 0x1F9CD, 0x1F9CF, 0x1F9D1, 0x1F9DF, 0x1F9E0, 0x1F9E0,
        0x1FAC0, 0x1FAC5, 0x1FAF0, 0x1FAF8, 0x261D, 0x261D, 0x270A, 0x270D, 0x26F9, 0x26F9
    )
    private val R_FOOD = intArrayOf(
        0x1F32D, 0x1F330, 0x1F336, 0x1F336, 0x1F33D, 0x1F33D, 0x1F345, 0x1F37F, 0x1F382, 0x1F382,
        0x1F950, 0x1F96F, 0x1F9C0, 0x1F9CB, 0x1FAD0, 0x1FADB, 0x2615, 0x2615
    )
    private val R_ANIMALS = intArrayOf(
        0x1F300, 0x1F30A, 0x1F311, 0x1F32C, 0x1F331, 0x1F344, 0x1F400, 0x1F43F, 0x1F490, 0x1F490,
        0x1F4AE, 0x1F4AE, 0x1F4A7, 0x1F4A7, 0x1F525, 0x1F525, 0x1F3F5, 0x1F3F5, 0x1F54A, 0x1F54A,
        0x1F577, 0x1F578, 0x1F980, 0x1F9AE, 0x1FAB0, 0x1FABF, 0x2600, 0x2604, 0x2614, 0x2614,
        0x2618, 0x2618, 0x2744, 0x2744, 0x26A1, 0x26A1, 0x26C4, 0x26C8
    )
    private val R_ACTIVITIES = intArrayOf(
        0x1F380, 0x1F381, 0x1F383, 0x1F384, 0x1F386, 0x1F3C0, 0x1F3C5, 0x1F3C6, 0x1F3C8, 0x1F3C9,
        0x1F3CF, 0x1F3D3, 0x1F3F8, 0x1F3F9, 0x1F947, 0x1F94F, 0x1F9E8, 0x1F9E9, 0x1F9FF, 0x1F9FF,
        0x1FA80, 0x1FA81, 0x1FA83, 0x1FA83, 0x1FA85, 0x1FA86, 0x1FAA9, 0x1FAA9, 0x26BD, 0x26BE,
        0x26F3, 0x26F3, 0x26F8, 0x26F8, 0x265F, 0x265F, 0x2660, 0x2660, 0x2663, 0x2663,
        0x2665, 0x2666, 0x1F0CF, 0x1F0CF, 0x1F004, 0x1F004
    )
    private val R_TRAVEL = intArrayOf(
        0x1F30B, 0x1F310, 0x1F3D4, 0x1F3F0, 0x1F5FA, 0x1F5FF, 0x1F680, 0x1F6A8, 0x1F6B2, 0x1F6B2,
        0x1F6D5, 0x1F6D7, 0x1F6DC, 0x1F6DF, 0x1F6E9, 0x1F6E9, 0x1F6EB, 0x1F6EC, 0x1F6F0, 0x1F6F0,
        0x1F6F3, 0x1F6FC, 0x1F488, 0x1F488, 0x2693, 0x2693, 0x2708, 0x2708, 0x26E9, 0x26EA,
        0x26F0, 0x26F2, 0x26F4, 0x26F5, 0x26FA, 0x26FA, 0x26FD, 0x26FD, 0x231B, 0x231B,
        0x23F3, 0x23F3, 0x23F0, 0x23F0, 0x1F550, 0x1F567, 0x1F570, 0x1F570, 0x1F6CE, 0x1F6CE,
        0x1F9F3, 0x1F9F3
    )
    private val R_SYMBOLS = intArrayOf(
        0x23, 0x23, 0x2A, 0x2A, 0x30, 0x39, 0xA9, 0xA9, 0xAE, 0xAE, 0x203C, 0x203C, 0x2049, 0x2049,
        0x2122, 0x2122, 0x2139, 0x2139, 0x2194, 0x2199, 0x21A9, 0x21AA, 0x24C2, 0x24C2, 0x25AA, 0x25AB,
        0x25B6, 0x25B6, 0x25C0, 0x25C0, 0x25FB, 0x25FE, 0x2640, 0x2640, 0x2642, 0x2642, 0x2648, 0x2653,
        0x267B, 0x267B, 0x267E, 0x267F, 0x2695, 0x2695, 0x26A0, 0x26A0, 0x26A7, 0x26A7, 0x26AA, 0x26AB,
        0x26CE, 0x26CE, 0x26D4, 0x26D4, 0x2705, 0x2705, 0x2714, 0x2714, 0x2716, 0x2716, 0x271D, 0x271D,
        0x2721, 0x2721, 0x2728, 0x2728, 0x2733, 0x2734, 0x2747, 0x2747, 0x274C, 0x274C, 0x274E, 0x274E,
        0x2753, 0x2755, 0x2757, 0x2757, 0x2795, 0x2797, 0x27B0, 0x27B0, 0x27BF, 0x27BF, 0x2934, 0x2935,
        0x2B05, 0x2B07, 0x2B1B, 0x2B1C, 0x2B50, 0x2B50, 0x2B55, 0x2B55, 0x3030, 0x3030, 0x303D, 0x303D,
        0x3297, 0x3297, 0x3299, 0x3299, 0x262A, 0x262A, 0x262E, 0x262F, 0x2638, 0x2638, 0x2626, 0x2626,
        0x2622, 0x2623, 0x2668, 0x2668, 0x1F170, 0x1F171, 0x1F17E, 0x1F17F, 0x1F18E, 0x1F18E,
        0x1F191, 0x1F19A, 0x1F201, 0x1F202, 0x1F21A, 0x1F21A, 0x1F22F, 0x1F22F, 0x1F232, 0x1F23A,
        0x1F250, 0x1F251, 0x1F4DB, 0x1F4DB, 0x1F4F3, 0x1F4F6, 0x1F500, 0x1F506, 0x1F51E, 0x1F524,
        0x1F530, 0x1F53D, 0x1F6AB, 0x1F6AB, 0x1F6AD, 0x1F6B1, 0x1F6B3, 0x1F6B3, 0x1F6B7, 0x1F6B8,
        0x1F6B9, 0x1F6BC, 0x1F6BE, 0x1F6BE, 0x1F6C2, 0x1F6C5, 0x1F6D0, 0x1F6D1, 0x1F7E0, 0x1F7EB,
        0x1F7F0, 0x1F7F0, 0x1F4AF, 0x1F4AF, 0x1F4B1, 0x1F4B2, 0x1F4B9, 0x1F4B9, 0x1F4F4, 0x1F4F4
    )

    private fun inRanges(cp: Int, a: IntArray): Boolean {
        var i = 0
        while (i < a.size) {
            if (cp >= a[i] && cp <= a[i + 1]) return true
            i += 2
        }
        return false
    }

    private fun category(cp: Int): Int = when {
        inRanges(cp, R_FLAGS) -> FLAGS
        inRanges(cp, R_SMILEYS) -> SMILEYS
        inRanges(cp, R_PEOPLE) -> PEOPLE
        inRanges(cp, R_FOOD) -> FOOD
        inRanges(cp, R_ANIMALS) -> ANIMALS
        inRanges(cp, R_ACTIVITIES) -> ACTIVITIES
        inRanges(cp, R_TRAVEL) -> TRAVEL
        inRanges(cp, R_SYMBOLS) -> SYMBOLS
        else -> OBJECTS
    }

    private fun isModBase(cp: Int): Boolean = try {
        UCharacter.hasBinaryProperty(cp, UProperty.EMOJI_MODIFIER_BASE)
    } catch (e: Throwable) {
        false
    }

    private fun canTone(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (isModBase(cp)) return true
            i += Character.charCount(cp)
        }
        return false
    }

    private fun hasToneModifier(s: String): Boolean {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (cp in 0x1F3FB..0x1F3FF) return true
            i += Character.charCount(cp)
        }
        return false
    }

    /** Insert the skin-tone modifier after every emoji that supports one. */
    fun applyTone(s: String, tone: Int): String {
        val mod = 0x1F3FB + tone - 1
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            sb.appendCodePoint(cp)
            i += Character.charCount(cp)
            if (isModBase(cp)) {
                if (i < s.length && s[i] == '\uFE0F') i++
                sb.appendCodePoint(mod)
            }
        }
        return sb.toString()
    }

    @Synchronized
    fun build() {
        if (ready) return
        val list = ArrayList<EmojiItem>()
        val seen = HashSet<String>()

        fun add(s: String) {
            if (s.isEmpty() || !seen.add(s)) return
            if (!paint.hasGlyph(s)) return
            list.add(EmojiItem(s, category(s.codePointAt(0)), canTone(s)))
        }

        var ok = false
        if (Build.VERSION.SDK_INT >= 33) {
            try {
                val set = UnicodeSet("[\\p{RGI_Emoji}]")
                for (s in set) {
                    if (!hasToneModifier(s)) add(s)
                }
                ok = list.size > 500
            } catch (e: Throwable) {
                ok = false
            }
        }
        if (!ok) {
            // Older phones: a basic set plus every flag the emoji font can draw.
            list.clear()
            seen.clear()
            val basic = "😀😃😄😁😆😅😂🤣😊😇🙂😉😍🥰😘😋😛😜🤪😎🤩🥳😏😒😞😔😟😕🙁😣😖😫😩🥺😢😭😤😠😡🤬🤯😳🥵🥶😱😨😰😥😓🤗🤔🤭🤫😶😐😑😬🙄😯😦😧😮😲😴🤤😪😵🤐🥴🤢🤮🤧😷🤒🤕🤑🤠😈👿👹👺🤡💩👻💀👽👾🤖🎃" +
                "👍👎👊✊🤛🤜🤞✌🤟🤘👌👈👉👆👇☝✋🤚🖐🖖👋🤙💪🙏🤝👏🙌👐🤲❤🧡💛💚💙💜🖤🤍🤎💔💕💞💓💗💖💘💝🔥✨⭐🌟💥🎉🎊🎈🎁🏆⚽🏀🍕🍔🍟🌭🍿🍩🍪🎂☕🍺🍷🚗✈🚀🌍🌈☀🌙⚡❄💧🌸🌹🐶🐱🐭🐰🦊🐻🐼🦁🐸🐵🐔🐧🦄📱💻📷💡💰✅❌❓❗💯"
            var i = 0
            while (i < basic.length) {
                val cp = basic.codePointAt(i)
                add(String(Character.toChars(cp)))
                i += Character.charCount(cp)
            }
            for (a in 0 until 26) {
                for (b in 0 until 26) {
                    add(String(Character.toChars(0x1F1E6 + a)) + String(Character.toChars(0x1F1E6 + b)))
                }
            }
        }
        list.sortWith(
            compareBy<EmojiItem>({ it.cat }, { it.base.codePointAt(0) }, { it.base.length }, { it.base })
        )
        items = list
        ready = true
    }

    /** Emoji for one category (0..8) with the skin tone applied where the font supports it. */
    fun display(cat: Int, tone: Int): List<String> {
        build()
        val out = ArrayList<String>()
        for (it in items) if (it.cat == cat) out.add(it.shown(tone, paint))
        return out
    }
}
